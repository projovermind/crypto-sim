// ── 공유 상태 (모든 mutable 변수 중앙 관리) ──────────────────────────────────

// constants.js에서 이동
var positions          = []
var observer           = null
var debounceTimer      = null
var seenPositionIds    = new Set()
var checkedPositionIds = null

// 말풍선 영구 캐시
var bubbleDataCache = new Map()  // posId -> { viewCount, reactions:[{blobSrc,count,chosen}] }
var injectedBubbles = new Map()  // fakeMid -> { text, pos }
var pendingBubbles  = new Map()  // posId -> { text, pos }

// comments.js에서 이동
var _userSettings    = null      // { templates, enabled, timing }
var _settingsFetched = false
var _tsCache         = new Map()

// api.js에서 이동
var _posCache     = null
var _posCacheTime = 0

// content.js에서 이동
var _commentAuthorsCache = new Map()  // posId -> { type: [authorName, ...] }
var _scrollObserver      = null
var _scrollDebounce      = null
var _insertedPositions   = []

// profit-card: 캐시 제거 — 항상 최신 이미지 fetch

// comment-ui.js에서 이동
var _commentOverlay = null
var _commentCache   = new Map()

// NEW: 댓글 수/작성자 캐시 (bug #3 수정 — 아바타 안정성)
var _replyDataCache = new Map()  // posId -> { commentCount, authorNames }
// ── 불변 상수 ────────────────────────────────────────────────────────────────
var TELEDIT_BUILD = 'v20260413-2000'  // 번들 버전 (디버그용)
var SERVER_URL    = 'https://crypto-sim-nu.vercel.app'
var STORAGE_KEYS  = ['token', 'enabled']
var ATTR          = 'data-position-id'
var CLS           = 'teledit-position'
var INSERT_BTN_ID = 'teledit-insert-btn'

// 고정 3종 리액션 doc-id (페이지에서 blob URL 조회용)
var REACTION_DOC_IDS = [
  '5098582486267462019',  // ❤️
  '5100483636361167223',  // 👍
  '4911350297600721490',  // 🔥
]

// getReaction() 호출용 이모티콘 문자열 (REACTION_DOC_IDS와 순서 일치)
var REACTION_EMOTICONS = ['❤', '👍', '🔥']

var COLOR = {
  OPEN:      { bg: '#1a3a5c', border: '#5eacd3' },
  CLOSED_TP: { bg: '#1a3d2a', border: '#4caf7d' },
  CLOSED_SL: { bg: '#3d1a1a', border: '#e05c5c' },
}

// 포지션 캐시 TTL (불변)
var _POS_CACHE_TTL = 10000
// ── 유틸리티 함수 ─────────────────────────────────────────────────────────────
// 순수 유틸 + 간단한 DOM 쿼리. chrome.* API 의존 없음.

function _rand(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a }

function isChannelView() {
  return !!document.querySelector('.bubble.channel-post')
}

// ── 색상 결정 ────────────────────────────────────────────────────────────────
function resolveColor(pos) {
  if (pos.status === 'OPEN') return COLOR.OPEN
  const reason = pos.status === 'CLOSED_TP' || pos.closeReason === 'TP' ? 'CLOSED_TP' : 'CLOSED_SL'
  return COLOR[reason]
}

// ── 시간 포맷 ────────────────────────────────────────────────────────────────
function fmtTimeKorean(dateStr) {
  const d = new Date(dateStr)
  const h = d.getHours()
  const m = d.getMinutes().toString().padStart(2, '0')
  const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h
  return (h < 12 ? '오전' : '오후') + ' ' + h12.toString().padStart(2, '0') + ':' + m
}

// ── 댓글 시간 포맷 (comment-ui.js에서 사용) ─────────────────────────────────
function _fmtCommentTime(date) {
  var d = date instanceof Date ? date : new Date(date)
  var h = d.getHours()
  var m = d.getMinutes().toString().padStart(2, '0')
  var h12 = h === 0 ? 12 : h > 12 ? h - 12 : h
  var ap = h < 12 ? 'AM' : 'PM'
  return h12 + ':' + m + ' ' + ap
}

// ── 날짜 라벨 포맷 ───────────────────────────────────────────────────────────
function _formatDateLabel(ts) {
  const d = new Date(ts * 1000)
  const today = new Date()
  const yest  = new Date(today); yest.setDate(today.getDate() - 1)
  if (d.toDateString() === today.toDateString()) return 'Today'
  if (d.toDateString() === yest.toDateString())  return 'Yesterday'
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric' })
}
// ── chrome.storage 관련 ──────────────────────────────────────────────────────

function loadSettings() {
  return new Promise((resolve) => chrome.storage.local.get(STORAGE_KEYS, resolve))
}

async function loadCheckedIds() {
  const data = await new Promise((r) => chrome.storage.local.get(['checkedPositions'], r))
  checkedPositionIds = data.checkedPositions ? new Set(data.checkedPositions.map(String)) : null
}

function filterChecked(posList) {
  // null(미설정) 또는 빈 Set → 전체 통과
  if (!checkedPositionIds || checkedPositionIds.size === 0) return posList
  return posList.filter(function(p) { return checkedPositionIds.has(String(p.id)) })
}
// ── 서버 API 통신 ────────────────────────────────────────────────────────────

// background worker를 통한 fetch (CORS 우회용 폴백)
function bgFetch(url, headers) {
  return new Promise(function(resolve) {
    try {
      chrome.runtime.sendMessage({ action: 'fetch', url: url, headers: headers }, function(res) {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, data: null, error: chrome.runtime.lastError.message })
        } else {
          resolve(res || { ok: false, data: null })
        }
      })
    } catch (e) {
      resolve({ ok: false, data: null, error: e.message })
    }
  })
}

// 직접 fetch 시도 → 실패(CORS) 시 bgFetch 폴백
async function safeFetch(url, headers) {
  try {
    var res = await fetch(url, { headers: headers })
    var data = await res.json()
    return { ok: res.ok, status: res.status, data: data }
  } catch (e) {
    // CORS 또는 네트워크 에러 → background proxy 폴백
    return await bgFetch(url, headers)
  }
}

// ── 포지션 캐시 (10초 TTL) ────────────────────────────────────────────────────

async function fetchPositions(serverUrl, token) {
  // 캐시 히트
  var now = Date.now()
  if (_posCache && (now - _posCacheTime) < _POS_CACHE_TTL) return _posCache

  var base = serverUrl.replace(/\/$/, '')
  var headers = token ? { Authorization: 'Bearer ' + token } : {}
  try {
    // 병렬 호출
    var results = await Promise.all([
      safeFetch(base + '/api/positions?status=OPEN', headers),
      safeFetch(base + '/api/positions?status=CLOSED', headers),
    ])
    var resOpen = results[0], resClosed = results[1]

    var openData   = resOpen.ok   ? resOpen.data   : []
    var closedData = resClosed.ok ? resClosed.data : []

    var open   = Array.isArray(openData)   ? openData   : (openData && openData.positions ? openData.positions : [])
    var closed = Array.isArray(closedData) ? closedData : (closedData && closedData.positions ? closedData.positions : [])

    _posCache = open.concat(closed).sort(
      function(a, b) { return new Date(a.entryTime) - new Date(b.entryTime) }
    )
    _posCacheTime = Date.now()
    return _posCache
  } catch (err) {
    console.error('[Teledit] fetchPositions 실패:', err)
    return _posCache || []
  }
}

// ── 포지션별 댓글 조회 ───────────────────────────────────────────────────────
async function fetchPositionComments(posId) {
  try {
    var settings = await loadSettings()
    if (!settings.token) return []
    var res = await safeFetch(
      SERVER_URL + '/api/positions/' + posId + '/comments',
      { Authorization: 'Bearer ' + settings.token },
    )
    if (res.ok && res.data && res.data.comments) return res.data.comments
    return []
  } catch (e) {
    console.warn('[Teledit] fetchPositionComments 실패:', e.message)
    return []
  }
}

// ── 포지션 컨텍스트 텍스트 생성 ───────────────────────────────────────────────
function buildContextText() {
  var open   = filterChecked(positions.filter(function(p) { return p.status === 'OPEN' }))
  var closed = filterChecked(positions.filter(function(p) { return p.status !== 'OPEN' })).slice(-5)
  function fmtLine(p, withResult) {
    var lev    = p.leverage  ? p.leverage + 'x ' : ''
    var time   = p.entryTime ? ' 진입시간 ' + fmtTimeKorean(p.entryTime) : ''
    var pnl    = p.pnl != null ? ' PnL ' + (Number(p.pnl) >= 0 ? '+' : '') + Number(p.pnl).toFixed(1) + '%' : ''
    var result = withResult ? ' [' + (p.status === 'CLOSED_TP' || p.closeReason === 'TP' ? 'TP' : 'SL') + ']' : ''
    return p.symbol + ' ' + p.side + ' ' + lev + '진입가 ' + p.entryPrice + time + pnl + result
  }
  var parts = []
  if (open.length)   parts.push('현재포지션: '  + open.map(function(p) { return fmtLine(p) }).join(' | '))
  if (closed.length) parts.push('최근청산: ' + closed.map(function(p) { return fmtLine(p, true) }).join(' | '))
  return parts.join('\n')
}
// ── Telegram DOM 요소 생성 팩토리 ────────────────────────────────────────────

// ── 현재 페이지에서 반응 스티커 blob URL 수집 ───────────────────────────────
function _getReactionBlobMap() {
  const map = {}
  document.querySelectorAll('.reaction-sticker[data-doc-id]').forEach(sticker => {
    const img = sticker.querySelector('img.media-sticker')
    if (img && img.src.startsWith('blob:')) {
      map[sticker.dataset.docId] = img.src
    }
  })
  return map
}

// ── 날짜 구분선 ────────────────────────────────────────────────────────────────
function _buildDateSeparator(entryTs) {
  const label = _formatDateLabel(entryTs)
  const sep = document.createElement('div')
  sep.className = 'teledit-date-sep'
  const lbl = document.createElement('span')
  lbl.className = 'teledit-date-label'
  lbl.textContent = label
  sep.appendChild(lbl)
  return sep
}

// ── 반응 버튼 구조 빌드 ───────────────────────────────────────────────────────
function _buildOneReaction(blobSrc, emoticon, count, chosen, posId, idx) {
  var div = document.createElement('div')
  div.className = 'reaction reaction-block reaction-like-block' + (chosen ? ' is-chosen' : '')

  var stickerWrap = document.createElement('div')
  stickerWrap.className = 'reaction-sticker is-regular media-sticker-wrapper'
  stickerWrap.dataset.docId = REACTION_DOC_IDS[idx] || ''

  if (blobSrc) {
    var img = document.createElement('img')
    img.className = 'media-sticker'
    img.src = blobSrc
    stickerWrap.appendChild(img)
  } else {
    // blob URL 없으면 이모지 텍스트로 폴백
    var emojiSpan = document.createElement('span')
    emojiSpan.style.cssText = 'font-size:20px;display:flex;align-items:center;justify-content:center;width:100%;height:100%;'
    emojiSpan.textContent = emoticon
    stickerWrap.appendChild(emojiSpan)
  }

  div.appendChild(stickerWrap)

  var counter = document.createElement('span')
  counter.className = 'reaction-counter'
  counter.textContent = String(count)
  div.appendChild(counter)

  return div
}
// ── 반응 클릭 인터셉터 ────────────────────────────────────────────────────────
// reactions-element.connectedCallback이 우리 div를 reaction-element 웹컴포넌트로
// 교체하므로, DOM 삽입 이후에 capture 리스너로 클릭을 가로채야 한다.

function _attachReactionInterceptor(reactionsEl, reactionData, posId) {
  reactionsEl.addEventListener('click', (e) => {
    const reactionEl = e.target.closest('reaction-element')
                    || e.target.closest('.reaction.reaction-block')
    if (!reactionEl || !reactionsEl.contains(reactionEl)) return

    e.stopImmediatePropagation()
    e.preventDefault()

    const allReactionEls = [...reactionsEl.querySelectorAll('reaction-element, .reaction.reaction-block')]
    const idx = allReactionEls.indexOf(reactionEl)
    if (idx === -1) return

    const isChosen  = reactionEl.classList.contains('is-chosen')
    const counter   = reactionEl.querySelector('.reaction-counter')
    const img       = reactionEl.querySelector('.media-sticker')
    const blobSrc   = img?.src
    const emoticon  = REACTION_EMOTICONS[idx]
    const rect      = reactionEl.getBoundingClientRect()

    if (!isChosen) {
      reactionEl.classList.add('animating')
      void reactionEl.offsetHeight
      reactionEl.classList.add('is-chosen')
      setTimeout(() => reactionEl.classList.remove('animating'), 320)
      if (counter) counter.textContent = String(parseInt(counter.textContent) + 1)

      // Telegram around_animation (page context lottie)
      if (emoticon) {
        const containerId = 'teledit-anim-' + Date.now()
        const animContainer = document.createElement('div')
        animContainer.id = containerId
        Object.assign(animContainer.style, {
          position: 'fixed',
          left: (rect.left + rect.width  / 2 - 40) + 'px',
          top:  (rect.top  + rect.height / 2 - 40) + 'px',
          width: '80px', height: '80px',
          zIndex: '99999', pointerEvents: 'none',
        })
        document.body.appendChild(animContainer)
        document.dispatchEvent(new CustomEvent('teledit-play-reaction', {
          detail: { containerId, emoticon },
        }))
      }

      // CSS 스티커 팝
      if (img) {
        img.style.animation = 'none'
        void img.offsetHeight
        img.style.animation = 'teledit-sticker-pop 0.42s ease'
        setTimeout(() => { img.style.animation = '' }, 420)
      }

      // 플로팅 이펙트
      if (blobSrc) {
        const floater = document.createElement('div')
        Object.assign(floater.style, {
          position: 'fixed',
          left: (rect.left + rect.width  / 2 - 14) + 'px',
          top:  (rect.top - 8) + 'px',
          width: '28px', height: '28px',
          zIndex: '99999', pointerEvents: 'none',
          animation: 'teledit-float-up 0.65s ease forwards',
        })
        const fImg = document.createElement('img')
        fImg.src = blobSrc
        fImg.style.cssText = 'width:100%;height:100%;object-fit:contain;'
        floater.appendChild(fImg)
        document.body.appendChild(floater)
        setTimeout(() => floater.remove(), 750)
      }

    } else {
      reactionEl.classList.add('backwards', 'animating')
      void reactionEl.offsetHeight
      reactionEl.classList.remove('is-chosen')
      setTimeout(() => reactionEl.classList.remove('backwards', 'animating'), 320)
      if (counter) counter.textContent = String(parseInt(counter.textContent) - 1)
    }

    // 캐시 갱신
    if (posId) {
      const data = bubbleDataCache.get(posId)
      if (data && data.reactions[idx]) {
        data.reactions[idx].count  = parseInt(counter?.textContent || '0')
        data.reactions[idx].chosen = reactionEl.classList.contains('is-chosen')
      }
    }
  }, true)
}
// ── 상황별 메시지 시스템 — 유저 설정 기반 템플릿 ─────────────────────────────
// 유저별 템플릿(DB) + 타이밍 + 활성화 설정을 API에서 fetch하여
// 포지션 데이터와 조합해 채널 포스트 생성.

// ── 포지션 메시지 생성 (OPEN / CLOSED 구분) — utils.js에서 이동 ─────────────
function buildAutoMessage(pos) {
  var lev   = pos.leverage ? pos.leverage + 'x' : ''
  var time  = pos.entryTime ? fmtTimeKorean(pos.entryTime) : ''
  // inputPrice(사용자 입력가) 우선, 없으면 entryPrice(슬리피지 적용) 반올림
  var price = pos.inputPrice || Number(pos.entryPrice)
  if (typeof price === 'number') price = parseFloat(price.toPrecision(8))

  if (pos.status === 'OPEN') {
    var tp = pos.takeProfit ? ' | TP: ' + pos.takeProfit : ''
    var sl = pos.stopLoss  ? ' | SL: ' + pos.stopLoss  : ''
    return '[' + pos.symbol + ' ' + pos.side + ' ' + lev + '] 진입가 ' + price + ' | 진입시간 ' + time + tp + sl
  }

  var reason = pos.closeReason === 'TP' || pos.status === 'CLOSED_TP' ? 'TP' : 'SL'
  var pnl    = pos.pnl != null ? ' ' + (Number(pos.pnl) >= 0 ? '+' : '') + Number(pos.pnl).toFixed(2) + '%' : ''
  var cp     = pos.closePrice ? ' | 청산가 ' + parseFloat(Number(pos.closePrice).toPrecision(8)) : ''
  return '[' + pos.symbol + ' ' + pos.side + ' ' + lev + '] 진입가 ' + price + cp + ' | ' + reason + pnl + ' | ' + time
}

// 기본 템플릿 (API 실패 시 폴백)
var _DEFAULTS = {
  preEntry:   '⏳ {{symbol}} {{side}} {{leverage}}x | 진입 예정 ${{entryPrice}}',
  long:       '🟢 {{symbol}} LONG {{leverage}}x | 진입 ${{entryPrice}}',
  short:      '🔴 {{symbol}} SHORT {{leverage}}x | 진입 ${{entryPrice}}',
  postEntry:  '📊 {{symbol}} {{side}} {{leverage}}x | 진입 완료 ${{entryPrice}}',
  preClose:   '⏳ {{symbol}} {{side}} | 청산 예정 PnL {{pnl}}USDT ({{roe}}%)',
  close:      '🔴 {{symbol}} {{side}} 청산 | PnL {{pnl}}USDT ({{roe}}%)',
  profit1:    '💰 수익 인증\n{{symbol}} {{side}} {{leverage}}x\n진입 ${{entryPrice}} → 청산 ${{closePrice}}\nPnL {{pnl}}USDT ({{roe}}%)',
  profit2:    '📈 수익 인증\n{{symbol}} {{side}} {{leverage}}x\nPnL {{pnl}}USDT ({{roe}}%)',
}

var _DEFAULT_TIMING = {
  preEntryMin: 60, preEntryMax: 120,
  postEntryMin: 30, postEntryMax: 60,
  preCloseMin: 60, preCloseMax: 120,
  profit1Min: 30, profit1Max: 60,
  profit2Min: 30, profit2Max: 60,
}

/**
 * 유저 설정 API fetch (최초 1회, 이후 캐시)
 */
async function fetchUserSettings() {
  if (_settingsFetched) return _userSettings
  _settingsFetched = true
  try {
    var settings = await loadSettings()
    if (!settings.token) return null
    var res = await safeFetch(
      SERVER_URL + '/api/user/settings',
      { Authorization: 'Bearer ' + settings.token },
    )
    if (res.ok && res.data && res.data.templates) {
      _userSettings = res.data
      console.log('[Teledit] 유저 설정 로드 완료')
      return _userSettings
    }
  } catch (e) {
    console.warn('[Teledit] 유저 설정 fetch 실패:', e.message)
  }
  return null
}

// ── 템플릿 변수 치환 (CryptoSim applyTemplate과 동일) ────────────────────────
function _applyTemplate(template, pos) {
  if (!template) return null
  var pnl = pos.pnl != null ? Number(pos.pnl).toFixed(2) : 'N/A'
  var roe = pos.pnl != null && pos.amount > 0
    ? (pos.pnl / pos.amount * pos.leverage * 100).toFixed(2)
    : 'N/A'
  var fmt = function(v) { return v != null ? String(v) : 'N/A' }
  return template
    .replace(/\{\{symbol\}\}/g, pos.symbol || '')
    .replace(/\{\{side\}\}/g, pos.side || '')
    .replace(/\{\{leverage\}\}/g, String(pos.leverage || ''))
    .replace(/\{\{entryPrice\}\}/g, fmt(pos.inputPrice || pos.entryPrice))
    .replace(/\{\{inputPrice\}\}/g, fmt(pos.inputPrice))
    .replace(/\{\{amount\}\}/g, fmt(pos.amount))
    .replace(/\{\{quantity\}\}/g, fmt(pos.quantity))
    .replace(/\{\{marginMode\}\}/g, pos.marginMode || 'CROSS')
    .replace(/\{\{takeProfit\}\}/g, fmt(pos.takeProfit))
    .replace(/\{\{stopLoss\}\}/g, fmt(pos.stopLoss))
    .replace(/\{\{pnl\}\}/g, pnl)
    .replace(/\{\{roe\}\}/g, roe)
    .replace(/\{\{closePrice\}\}/g, fmt(pos.closedPrice))
}

// ── 타임스탬프 캐시 ──────────────────────────────────────────────────────────

function _cachedTs(posId, type, entryMs, closeMs) {
  var key = posId + ':' + type
  if (_tsCache.has(key)) return _tsCache.get(key)
  var t = _userSettings ? _userSettings.timing : _DEFAULT_TIMING
  var ts
  switch (type) {
    case 'preEntry':   ts = entryMs - _rand(t.preEntryMin, t.preEntryMax) * 1000; break
    case 'long':
    case 'short':      ts = entryMs; break
    case 'postEntry':  ts = entryMs + _rand(t.postEntryMin, t.postEntryMax) * 1000; break
    case 'postEntry1': ts = entryMs + _rand(t.postEntryMin + 30, t.postEntryMax + 60) * 1000; break
    case 'postEntry2': ts = entryMs + _rand(t.postEntryMin + 90, t.postEntryMax + 120) * 1000; break
    case 'postEntry3': ts = entryMs + _rand(t.postEntryMin + 150, t.postEntryMax + 180) * 1000; break
    case 'preClose':   ts = (closeMs || entryMs) - _rand(t.preCloseMin, t.preCloseMax) * 1000; break
    case 'close':      ts = closeMs || entryMs + 1800000; break
    case 'postClose1': ts = (closeMs || entryMs) + _rand(30, 90) * 1000; break
    case 'postClose2': ts = (closeMs || entryMs) + _rand(120, 240) * 1000; break
    case 'postClose3': ts = (closeMs || entryMs) + _rand(300, 480) * 1000; break
    // profit2는 profit1 이후로 보장: profit1 최대값 이후부터 시작
    case 'profit1':    ts = (closeMs || entryMs) + _rand(t.profit1Min, t.profit1Max) * 1000; break
    case 'profit2':    ts = (closeMs || entryMs) + (t.profit1Max + _rand(t.profit2Min, t.profit2Max)) * 1000; break
    default:           ts = entryMs; break
  }
  _tsCache.set(key, ts)
  return ts
}

// ── 메시지 슬롯 정의 ─────────────────────────────────────────────────────────
// phase: 'entry' = entryTime 기반, 'close' = closedAt 기반
var MESSAGE_SLOTS = [
  { type: 'preEntry',   phase: 'entry', templateKey: 'preEntry',   enabledKey: 'preEntry' },
  { type: 'long',       phase: 'entry', templateKey: 'long',       enabledKey: 'long',   sideFilter: 'LONG' },
  { type: 'short',      phase: 'entry', templateKey: 'short',      enabledKey: 'short',  sideFilter: 'SHORT' },
  { type: 'postEntry',  phase: 'entry', templateKey: 'postEntry',  enabledKey: 'postEntry' },
  { type: 'postEntry1', phase: 'entry', templateKey: 'postEntry1', enabledKey: 'postEntry1' },
  { type: 'postEntry2', phase: 'entry', templateKey: 'postEntry2', enabledKey: 'postEntry2' },
  { type: 'postEntry3', phase: 'entry', templateKey: 'postEntry3', enabledKey: 'postEntry3' },
  { type: 'preClose',   phase: 'close', templateKey: 'preClose',   enabledKey: 'preClose' },
  { type: 'close',      phase: 'close', templateKey: 'close',      enabledKey: 'close' },
  { type: 'postClose1', phase: 'close', templateKey: 'postClose1', enabledKey: 'postClose1' },
  { type: 'postClose2', phase: 'close', templateKey: 'postClose2', enabledKey: 'postClose2' },
  { type: 'postClose3', phase: 'close', templateKey: 'postClose3', enabledKey: 'postClose3' },
  { type: 'profit1',    phase: 'close', templateKey: 'profit1',    enabledKey: 'profit1' },
  { type: 'profit2',    phase: 'close', templateKey: 'profit2',    enabledKey: 'profit2' },
]

/**
 * 포지션 → 상황별 채널 포스트 메시지 배열 생성
 */
function buildPositionMessages(pos) {
  var posId = String(pos.id)
  var entryMs = new Date(pos.entryTime).getTime()
  var closeMs = pos.closedAt ? new Date(pos.closedAt).getTime() : null
  var side = (pos.side || 'LONG').toUpperCase()
  var isClosed = (pos.status || 'OPEN') !== 'OPEN'
  var now = Date.now()

  var templates = _userSettings ? _userSettings.templates : _DEFAULTS
  var enabled = _userSettings ? _userSettings.enabled : {}

  var result = []
  for (var i = 0; i < MESSAGE_SLOTS.length; i++) {
    var slot = MESSAGE_SLOTS[i]

    // side 필터
    if (slot.sideFilter && slot.sideFilter !== side) continue

    // close phase는 청산된 포지션만
    if (slot.phase === 'close' && !isClosed) continue

    // 활성화 체크
    if (enabled[slot.enabledKey] === false) continue

    // 템플릿 확인
    var tmpl = templates[slot.templateKey]
    if (!tmpl) continue

    // 변수 치환
    var text = _applyTemplate(tmpl, pos)
    if (!text || !text.trim()) continue

    // 타이밍
    var ts = _cachedTs(posId, slot.type, entryMs, closeMs)
    if (ts > now) continue

    var countMap = {
      preEntry: 'preEntryCount', long: 'longCount', short: 'shortCount',
      postEntry: 'postEntryCount', postEntry1: 'postEntryCount', postEntry2: 'postEntryCount', postEntry3: 'postEntryCount',
      preClose: 'preCloseCount',
      close: 'closeCount', postClose1: 'closeCount', postClose2: 'closeCount', postClose3: 'closeCount',
      profit1: 'profit1Count', profit2: 'profit2Count',
    }
    result.push({
      id: posId + '-' + slot.type,
      text: text,
      entryTime: new Date(ts).toISOString(),
      type: slot.type,
      _ts: ts,
      commentCount: (pos.positionCommentCount && countMap[slot.type] != null) ? (pos.positionCommentCount[countMap[slot.type]] || 0) : null,
    })
  }

  // 시간순 정렬 — 항상 오래된 것부터
  result.sort(function(a, b) { return a._ts - b._ts })

  return result
}
// ── 수익인증 카드 이미지 — 서버 API에서 가져오기 ─────────────────────────────

/**
 * 서버에서 수익인증 카드 이미지를 가져와 blob URL로 반환
 */
async function fetchProfitCardImage(posId) {
  try {
    var settings = await loadSettings()
    if (!settings.token) return null

    var url = SERVER_URL + '/api/profit-card/' + posId

    // 1) 직접 fetch 시도
    try {
      var res = await fetch(url, {
        headers: { Authorization: 'Bearer ' + settings.token },
      })
      if (res.ok) {
        var blob = await res.blob()
        if (blob.size > 100) {
          return URL.createObjectURL(blob)
        }
      }
    } catch (e) { /* CORS → proxy 폴백 */ }

    // 2) Background proxy 폴백 (CORS 우회)
    var bgRes = await new Promise(function(resolve) {
      try {
        chrome.runtime.sendMessage({
          action: 'fetchBlob',
          url: url,
          headers: { Authorization: 'Bearer ' + settings.token },
        }, function(response) {
          resolve(response || { dataUrl: null })
        })
      } catch (e) {
        resolve({ dataUrl: null })
      }
    })

    if (bgRes && bgRes.dataUrl) {
      return bgRes.dataUrl
    }

    console.warn('[Teledit] profit card: 직접 fetch + proxy 모두 실패')
    return null
  } catch (e) {
    console.warn('[Teledit] profit card 에러:', e.message)
    return null
  }
}
// ── 가짜 댓글 UI — Telegram Discussion 뷰 재현 ─────────────────────────────
// Telegram Web의 댓글 뷰를 그대로 재현:
//   헤더: "← N Comments" + 핀 메시지
//   본문: "Discussion started" 서비스 메시지 + 그룹 채팅 말풍선
//   하단: "Comment" 입력 바

function toggleCommentThread(bubble, pos) {
  if (_commentOverlay) { closeCommentThread(); return }
  showCommentThread(bubble, pos)
}

async function showCommentThread(bubble, pos) {
  if (_commentOverlay) closeCommentThread()

  var posId = pos ? String(pos.id) : null
  var msgEl = bubble.querySelector('.translatable-message')
  var originalText = msgEl ? msgEl.textContent.trim() : ''
  var timeEl = bubble.querySelector('.time .i18n')
  var originalTime = timeEl ? timeEl.textContent.trim() : ''
  var entryDate = pos && pos.entryTime ? new Date(pos.entryTime) : new Date()

  // ── 전체 오버레이 (채팅 영역 대체) ──
  var overlay = document.createElement('div')
  overlay.id = 'teledit-comment-overlay'
  overlay.className = 'teledit-disc-overlay'

  // ── 헤더 바 ──
  var headerBar = document.createElement('div')
  headerBar.className = 'teledit-disc-header'

  var backBtn = document.createElement('button')
  backBtn.className = 'teledit-disc-back'
  var backIcon = document.createElement('span')
  backIcon.className = 'tgico tgico-back teledit-disc-back-icon'
  backBtn.appendChild(backIcon)
  backBtn.addEventListener('click', function() { closeCommentThread() })

  var headerTitle = document.createElement('div')
  headerTitle.className = 'teledit-disc-header-title'
  headerTitle.textContent = 'Comments'

  var headerCount = document.createElement('span')
  headerCount.className = 'teledit-disc-header-count'
  headerCount.textContent = ''

  headerBar.appendChild(backBtn)
  headerBar.appendChild(headerTitle)
  headerBar.appendChild(headerCount)

  // ── 핀 메시지 바 ──
  var pinBar = document.createElement('div')
  pinBar.className = 'teledit-disc-pin'

  var pinLabel = document.createElement('div')
  pinLabel.className = 'teledit-disc-pin-label'
  pinLabel.textContent = 'Pinned Message'

  var pinText = document.createElement('div')
  pinText.className = 'teledit-disc-pin-text'
  // 긴 텍스트 잘라내기
  var truncated = originalText.length > 60 ? originalText.substring(0, 57) + '...' : originalText
  pinText.textContent = truncated

  pinBar.appendChild(pinLabel)
  pinBar.appendChild(pinText)

  // ── 메시지 영역 ──
  var messagesArea = document.createElement('div')
  messagesArea.className = 'teledit-disc-messages'

  // "Discussion started" 서비스 메시지
  var serviceMsg = document.createElement('div')
  serviceMsg.className = 'teledit-disc-service'
  var serviceBubble = document.createElement('div')
  serviceBubble.className = 'teledit-disc-service-inner'
  serviceBubble.textContent = 'Discussion started'
  serviceMsg.appendChild(serviceBubble)
  messagesArea.appendChild(serviceMsg)

  // 로딩 표시
  var loadingEl = document.createElement('div')
  loadingEl.className = 'teledit-disc-loading'
  loadingEl.textContent = 'Loading...'
  messagesArea.appendChild(loadingEl)

  // ── 입력 바 ──
  var inputBar = document.createElement('div')
  inputBar.className = 'teledit-disc-input-bar'

  var inputAvatar = document.createElement('div')
  inputAvatar.className = 'teledit-disc-input-avatar'
  inputAvatar.textContent = 'Y'

  var emojiBtn = document.createElement('span')
  emojiBtn.className = 'teledit-disc-input-icon tgico tgico-smile'

  var inputField = document.createElement('div')
  inputField.className = 'teledit-disc-input-field'
  inputField.setAttribute('contenteditable', 'true')
  inputField.setAttribute('data-placeholder', 'Comment')
  inputField.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      _submitDiscComment(inputField, messagesArea, entryDate)
    }
  })

  var attachBtn = document.createElement('span')
  attachBtn.className = 'teledit-disc-input-icon tgico tgico-attach'

  var micBtn = document.createElement('span')
  micBtn.className = 'teledit-disc-input-icon tgico tgico-microphone'

  inputBar.appendChild(inputAvatar)
  inputBar.appendChild(emojiBtn)
  inputBar.appendChild(inputField)
  inputBar.appendChild(attachBtn)
  inputBar.appendChild(micBtn)

  // ── 조립 ──
  overlay.appendChild(headerBar)
  overlay.appendChild(pinBar)
  overlay.appendChild(messagesArea)
  overlay.appendChild(inputBar)

  // ESC 닫기
  var escHandler = function(e) {
    if (e.key === 'Escape') {
      closeCommentThread()
      document.removeEventListener('keydown', escHandler)
    }
  }
  document.addEventListener('keydown', escHandler)

  // ── 채팅 영역 위에 오버레이 ──
  var chatContainer = document.querySelector('.chat') || document.querySelector('.chats-container') || document.body
  chatContainer.appendChild(overlay)
  _commentOverlay = overlay

  // ── API fetch ──
  var comments = posId ? _commentCache.get(posId) : null
  if (!comments && posId) {
    comments = await fetchPositionComments(posId)
    if (comments.length > 0) _commentCache.set(posId, comments)
  }
  if (!comments) comments = []

  if (!_commentOverlay) return

  // ── 로딩 제거 → 댓글 렌더 ──
  loadingEl.remove()

  comments.forEach(function(c, idx) {
    var offset = (idx + 1) * _rand(60, 300) * 1000
    var commentTime = new Date(entryDate.getTime() + offset)
    var msgBubble = _buildDiscBubble(c.writer, c.text, commentTime)
    messagesArea.appendChild(msgBubble)
  })

  // 헤더 카운트 갱신
  headerCount.textContent = comments.length > 0 ? comments.length + ' Comments' : ''
  headerTitle.textContent = comments.length > 0 ? '' : 'Comments'

  requestAnimationFrame(function() {
    messagesArea.scrollTop = messagesArea.scrollHeight
  })
}

function closeCommentThread() {
  if (_commentOverlay) {
    _commentOverlay.classList.add('closing')
    setTimeout(function() {
      if (_commentOverlay) {
        _commentOverlay.remove()
        _commentOverlay = null
      }
    }, 200)
  }
}

// ── 사용자 댓글 입력 ─────────────────────────────────────────────────────────
function _submitDiscComment(field, messagesArea, entryDate) {
  var text = field.textContent.trim()
  if (!text) return
  var writer = { name: 'You', color: '#6ab3f3' }
  var msgBubble = _buildDiscBubble(writer, text, new Date())
  messagesArea.appendChild(msgBubble)
  messagesArea.scrollTop = messagesArea.scrollHeight
  field.textContent = ''
}

// ── 그룹 채팅 스타일 댓글 말풍선 ─────────────────────────────────────────────
function _buildDiscBubble(writer, text, time) {
  var wrap = document.createElement('div')
  wrap.className = 'teledit-disc-bubble-wrap'

  // 아바타
  var avatar = document.createElement('div')
  avatar.className = 'teledit-disc-avatar'
  if (writer.avatarUrl) {
    var img = document.createElement('img')
    img.src = writer.avatarUrl
    img.style.cssText = 'width:100%;height:100%;border-radius:50%;object-fit:cover;'
    avatar.appendChild(img)
  } else {
    avatar.style.background = writer.color || '#65aadd'
    avatar.textContent = (writer.name || '?').charAt(0).toUpperCase()
  }

  // 말풍선
  var bubble = document.createElement('div')
  bubble.className = 'teledit-disc-bubble'

  // 발신자명
  var nameEl = document.createElement('div')
  nameEl.className = 'teledit-disc-name'
  nameEl.style.color = writer.color || '#65aadd'
  nameEl.textContent = writer.name

  // 메시지 + 시간
  var bodyRow = document.createElement('div')
  bodyRow.className = 'teledit-disc-body-row'

  var bodyText = document.createElement('span')
  bodyText.className = 'teledit-disc-body'
  bodyText.textContent = text

  var timeEl = document.createElement('span')
  timeEl.className = 'teledit-disc-time'
  timeEl.textContent = _fmtCommentTime(time)

  bodyRow.appendChild(bodyText)
  bodyRow.appendChild(timeEl)

  bubble.appendChild(nameEl)
  bubble.appendChild(bodyRow)

  wrap.appendChild(avatar)
  wrap.appendChild(bubble)

  return wrap
}
// ── 말풍선 데이터 계산 ───────────────────────────────────────────────────────

// ── 뷰 카운트 계산 (dom-helpers.js에서 이동) ────────────────────────────────
function _getViewsBetween(entryTs) {
  const bubbles = [...document.querySelectorAll('.bubble.channel-post[data-timestamp]:not(.teledit-injected)')]
    .sort((a, b) => parseInt(a.dataset.timestamp, 10) - parseInt(b.dataset.timestamp, 10))

  let before = null, after = null
  for (const b of bubbles) {
    const ts = parseInt(b.dataset.timestamp, 10)
    const v  = parseInt(b.querySelector('.post-views')?.textContent?.replace(/[^0-9]/g, '') || '0')
    if (ts <= entryTs) before = v
    else if (after === null) { after = v; break }
  }

  if (before !== null && after !== null) return _rand(Math.min(before, after), Math.max(before, after))
  if (before !== null) return _rand(Math.max(1, before - 8), before)
  if (after !== null)  return _rand(after + 5, after + 25)
  return _rand(450, 650)
}

// ── 댓글 수/작성자 캐시 (bug #3 수정) ───────────────────────────────────────
// reinject 시 _rand 재계산으로 아바타가 바뀌는 문제를 posId별 캐시로 해결
function _getReplyData(posId, msgType, dbAuthors, pos) {
  if (_replyDataCache.has(posId)) return _replyDataCache.get(posId)

  var commentCount = 0
  if (pos && pos._commentCount != null) {
    // DB 고정값 사용
    commentCount = pos._commentCount
  } else if (msgType && _userSettings && _userSettings.commentCounts) {
    // DB 값 없을 때 posId 해시 기반 결정론적 계산 (랜덤X → 새로고침 후에도 동일)
    var cc = _userSettings.commentCounts[msgType]
    if (cc && cc.max > 0) {
      var _seed = 0
      for (var _si = 0; _si < posId.length; _si++) _seed = (_seed * 31 + posId.charCodeAt(_si)) | 0
      commentCount = cc.min + Math.abs(_seed) % Math.max(1, cc.max - cc.min + 1)
    }
  }

  var avatarCount = Math.min(commentCount, 3)
  var authorNames = []
  if (dbAuthors && dbAuthors.length >= avatarCount) {
    for (var an = 0; an < avatarCount; an++) authorNames.push(dbAuthors[an])
  } else {
    var fallbackNames = ['해박','J','카파','금안','TP','HG','야미','준음']
    for (var fn = 0; fn < avatarCount; fn++) {
      authorNames.push(fallbackNames[(posId.charCodeAt(fn + 3) || fn) % fallbackNames.length])
    }
  }

  var data = { commentCount: commentCount, authorNames: authorNames }
  _replyDataCache.set(posId, data)
  return data
}
// ── 댓글 영역 렌더링 ────────────────────────────────────────────────────────

function _buildRepliesFooter(bubble, pos, posId) {
  var repliesRe = bubble.querySelector('replies-element')
  if (!repliesRe) return

  // connectedCallback 데이터 로드 차단
  repliesRe.removeAttribute('data-post-key')

  // 댓글 수/작성자: 캐시에서 가져오기 (bug #3 수정 — 안정적 아바타)
  var _msgType = pos && pos._messageType ? pos._messageType : null
  var _dbAuthors = pos && pos._commentAuthors ? pos._commentAuthors : null
  var replyData = _getReplyData(posId, _msgType, _dbAuthors, pos)
  var _commentCount = replyData.commentCount
  var authorNames = replyData.authorNames

  // 채널 아바타가 설정돼 있으면 첫 번째 아바타로 사용
  if (_commentCount > 0 && _userSettings && _userSettings.channelAvatarUrl && authorNames.length < 3) {
    authorNames = ['__channel__'].concat(authorNames).slice(0, 3)
  }

  // Telegram K 아바타 색상
  var _tgColors = ['red', 'green', 'violet', 'cyan', 'blue', 'pink', 'orange']

  var _cleanReplies = function(el) {
    // 기존 아바타/짧은답장 제거
    el.querySelectorAll('.stacked-avatars, .replies-short').forEach(function(c) { c.remove() })

    if (_commentCount === 0) {
      // .replies-footer가 있을 때만 아이콘 교체 (없으면 기존 것 유지)
      var footerInner = el.querySelector('.replies-footer')
      if (footerInner) {
        footerInner.querySelectorAll('.replies-footer-icon-comments').forEach(function(c) { c.remove() })
        var icon = document.createElement('span')
        icon.className = 'tgico replies-footer-icon replies-footer-icon-comments'
        footerInner.insertBefore(icon, footerInner.firstChild)
      }
    } else {
      // 아바타가 있을 때는 comments 아이콘 제거
      el.querySelectorAll('.replies-footer-icon-comments').forEach(function(c) { c.remove() })
    }

    // 댓글 수 텍스트
    var ftxt = el.querySelector('.replies-footer-text .i18n') || el.querySelector('.i18n')
    if (ftxt) {
      ftxt.textContent = _commentCount > 0
        ? _commentCount + (_commentCount === 1 ? ' Comment' : ' Comments')
        : 'Leave a comment'
    }

    // 댓글 아바타 (최대 3개) — 캐시된 작성자 사용
    if (_commentCount > 0) {
      var avatarCount = authorNames.length

      var wrap = document.createElement('div')
      wrap.className = 'stacked-avatars replies-footer-avatars'
      wrap.style.setProperty('--avatar-size', '30px')

      for (var ai = 0; ai < avatarCount; ai++) {
        var container = document.createElement('div')
        container.className = 'stacked-avatars-avatar-container'
        if (ai === 0) container.classList.add('is-first')
        if (ai === avatarCount - 1) container.classList.add('is-last')

        var avatar = document.createElement('div')
        avatar.className = 'avatar avatar-like avatar-30 avatar-gradient stacked-avatars-avatar'
        if (authorNames[ai] === '__channel__' && _userSettings && _userSettings.channelAvatarUrl) {
          // 채널 아바타 이미지 렌더링
          var img = document.createElement('img')
          img.src = _userSettings.channelAvatarUrl
          img.style.cssText = 'width:100%;height:100%;border-radius:50%;object-fit:cover;'
          avatar.style.background = 'transparent'
          avatar.appendChild(img)
        } else {
          // 이름 해시로 색상 결정
          var nameHash = 0
          for (var ch = 0; ch < authorNames[ai].length; ch++) nameHash += authorNames[ai].charCodeAt(ch)
          avatar.setAttribute('data-color', _tgColors[nameHash % _tgColors.length])
          // 이름의 첫 글자(들) — 한글이면 2자, 영문이면 1자
          var initial = authorNames[ai].slice(0, authorNames[ai].charCodeAt(0) > 255 ? 2 : 1)
          avatar.textContent = initial
        }

        container.appendChild(avatar)
        wrap.appendChild(container)
      }

      el.insertBefore(wrap, el.firstChild)
    }
  }

  // connectedCallback 재렌더링 대응 — 5초간 계속 감시 후 해제
  var _repliesObs = new MutationObserver(function() {
    _repliesObs.disconnect()
    _cleanReplies(repliesRe)
    _repliesObs.observe(repliesRe, { childList: true, subtree: true })
  })
  _repliesObs.observe(repliesRe, { childList: true, subtree: true })
  setTimeout(function() { _cleanReplies(repliesRe) }, 300)
  setTimeout(function() { _cleanReplies(repliesRe) }, 800)
  setTimeout(function() { _repliesObs.disconnect() }, 5000)

  // ── "Leave a comment" 클릭 -> 가짜 댓글 스레드 열기 ──
  var _posRef = pos
  repliesRe.style.cursor = 'pointer'
  repliesRe.addEventListener('click', function(e) {
    e.stopPropagation()
    e.preventDefault()
    toggleCommentThread(bubble, _posRef)
  }, true)
}
// ── 리액션 요소 구성 ────────────────────────────────────────────────────────

function _buildBubbleReactions(bubble, pos, posId, entryTs) {
  // 캐시 or 새 데이터
  var cached    = posId ? bubbleDataCache.get(posId) : null
  var viewCount = cached ? cached.viewCount : _getViewsBetween(entryTs)

  // 현재 페이지의 스티커 blob URL 맵
  var blobMap = _getReactionBlobMap()
  var reactionData = cached
    ? cached.reactions
    : REACTION_DOC_IDS.map(function(docId, i) {
        return {
          blobSrc:  blobMap[docId] || '',
          emoticon: REACTION_EMOTICONS[i],
          count:    _rand(20, 30),
          chosen:   false,
        }
      })

  // ── reactions-element -> 일반 div로 교체
  var origReactionsEl = bubble.querySelector('reactions-element')
  var reactionsEl = null
  if (origReactionsEl) {
    var origTime = origReactionsEl.querySelector('.time')
    reactionsEl = document.createElement('div')
    reactionsEl.className = origReactionsEl.className
    reactionData.forEach(function(r, idx) {
      var btn = _buildOneReaction(r.blobSrc, r.emoticon, r.count, r.chosen, posId, idx)
      if (idx === reactionData.length - 1) btn.classList.add('is-last')
      reactionsEl.appendChild(btn)
    })
    if (origTime) {
      var timeCopy = origTime.cloneNode(true)
      reactionsEl.appendChild(timeCopy)
    }

    // 항상 원래 위치(.message 안)에 교체. profit1은 bubble.js에서 별도 이동
    origReactionsEl.replaceWith(reactionsEl)
  }

  // 캐시 저장 (최초 1회)
  if (posId && !cached) {
    bubbleDataCache.set(posId, { viewCount: viewCount, reactions: reactionData })
  }

  return { reactionsEl: reactionsEl, reactionData: reactionData, viewCount: viewCount }
}
// ── 그룹/위치/날짜그룹 ──────────────────────────────────────────────────────

// ── 그룹 정보 계산 (dom-helpers.js에서 이동) ────────────────────────────────
// 2분(120s) 기준으로 이전/다음 포스트와의 그룹 경계를 판단한다.
function _getGroupInfo(entryTs) {
  const THRESHOLD = 120
  const bubbles = [...document.querySelectorAll('.bubble.channel-post[data-timestamp]')]
    .sort((a, b) => parseInt(a.dataset.timestamp, 10) - parseInt(b.dataset.timestamp, 10))

  let prevTs = null, nextTs = null
  for (const b of bubbles) {
    const ts = parseInt(b.dataset.timestamp, 10)
    if (ts <= entryTs) prevTs = ts
    else if (nextTs === null) { nextTs = ts; break }
  }

  return {
    isGroupFirst: prevTs === null || (entryTs - prevTs) >= THRESHOLD,
    isGroupLast:  nextTs === null || (nextTs - entryTs) >= THRESHOLD,
    prevTs: prevTs, nextTs: nextTs,
  }
}

// ── DOM 삽입 및 그룹 처리 ────────────────────────────────────────────────────
function _insertBubbleIntoDOM(bubble, group, entryTs, pos, posId, isGroupFirst, isGroupLast, forceInsert) {
  var joinedExistingGroup = false

  if (!isGroupFirst) {
    var prevInjected = [...document.querySelectorAll('.bubble.channel-post.teledit-injected[data-timestamp]')]
      .filter(function(b) {
        var ts = parseInt(b.dataset.timestamp, 10)
        return ts < entryTs && (entryTs - ts) < 120
      })
      .sort(function(a, b) { return parseInt(b.dataset.timestamp, 10) - parseInt(a.dataset.timestamp, 10) })[0]

    if (prevInjected) {
      var prevGroup = prevInjected.closest('.bubbles-group.teledit-injected-group')
      if (prevGroup) {
        group = prevGroup
        prevGroup.appendChild(bubble)
        joinedExistingGroup = true
        prevInjected.classList.remove('is-group-last', 'can-have-tail')
        prevInjected.querySelector('.bubble-tail')?.remove()
      }
    }
  }

  if (!joinedExistingGroup) {
    group.appendChild(bubble)

    var allPosts = document.querySelectorAll('.bubble.channel-post[data-timestamp]')
    var sameDayPosts = []
    allPosts.forEach(function(b) { sameDayPosts.push(b) })
    sameDayPosts.sort(function(a, b) {
      return parseInt(a.dataset.timestamp) - parseInt(b.dataset.timestamp)
    })

    var realPosts = document.querySelectorAll('.bubble.channel-post[data-timestamp]:not(.teledit-injected)')
    var inserted = false
    if (realPosts.length) {
      var minRealTs = Infinity
      realPosts.forEach(function(b) {
        var ts = parseInt(b.dataset.timestamp, 10)
        if (ts < minRealTs) minRealTs = ts
      })
      var maxRealTs = -Infinity
      realPosts.forEach(function(b) { var ts = parseInt(b.dataset.timestamp, 10); if (ts > maxRealTs) maxRealTs = ts })
      if (!forceInsert && (entryTs < minRealTs || entryTs > maxRealTs)) {
        if (posId) pendingBubbles.set(posId, { text: bubble.querySelector('.translatable-message')?.textContent || '', pos: pos })
        bubble.remove()
        group.remove()
        return false
      }
    }
    if (sameDayPosts.length) {
      var insertBefore = null
      for (var j = 0; j < sameDayPosts.length; j++) {
        if (parseInt(sameDayPosts[j].dataset.timestamp) > entryTs) {
          insertBefore = sameDayPosts[j]
          break
        }
      }
      if (insertBefore) {
        var pg = insertBefore.closest('.bubbles-group')
        if (pg && pg.parentElement) {
          pg.parentElement.insertBefore(group, pg)
          inserted = true
        }
      }
      if (!inserted) {
        var lastPg = sameDayPosts[sameDayPosts.length - 1].closest('.bubbles-group')
        if (lastPg && lastPg.parentElement) {
          lastPg.parentElement.insertBefore(group, lastPg.nextSibling)
          inserted = true
        }
      }
    }
    if (!inserted) {
      var dg = document.querySelectorAll('.bubbles-date-group')
      if (dg.length) dg[dg.length - 1].appendChild(group)
    }

    // ── sticky 헤더 수정: 다른 날짜의 date-group에 삽입됐으면 별도 date-group 생성
    var parentDateGroup = group.closest('.bubbles-date-group')
    if (parentDateGroup) {
      // Telegram 실제 날짜 헤더 OR teledit 날짜 라벨 중 존재하는 것으로 현재 날짜 확인
      var dgDateBubble = parentDateGroup.querySelector('.bubble.service.is-date')
      var teleditLbl = parentDateGroup.querySelector('.teledit-date-label')
      var dgText = dgDateBubble
        ? (dgDateBubble.querySelector('.i18n') || dgDateBubble).textContent.trim()
        : (teleditLbl ? teleditLbl.textContent.trim() : null)

      var myLabel = _formatDateLabel(entryTs)

      if (dgText && dgText !== myLabel) {
        var _par = parentDateGroup.parentElement

        // 이미 같은 날짜의 teledit 그룹이 있으면 재사용 (중복 날짜 헤더 방지)
        var existingTeleditGroup = null
        _par.querySelectorAll('.bubbles-date-group.teledit-date-group').forEach(function(dg) {
          var lbl = dg.querySelector('.teledit-date-label')
          if (lbl && lbl.textContent.trim() === myLabel) existingTeleditGroup = dg
        })

        if (existingTeleditGroup) {
          existingTeleditGroup.appendChild(group)
        } else {
          var newDateGroup = document.createElement('div')
          newDateGroup.className = 'bubbles-date-group teledit-date-group'
          newDateGroup.appendChild(_buildDateSeparator(entryTs))
          newDateGroup.appendChild(group)
          // 포지션 날짜 ≤ 기준 그룹 날짜 → 기준 그룹 앞에 삽입 (시간순 유지)
          _par.insertBefore(newDateGroup, parentDateGroup)
        }
      }
    }

    // ── 이전 그룹과의 간격 ──
    var prevGroupEl = group.previousElementSibling
    if (prevGroupEl && prevGroupEl.classList.contains('bubbles-group')) {
      if (!isGroupFirst) {
        var lastPrevBubble = prevGroupEl.querySelector('.bubble:last-child')
        if (lastPrevBubble) {
          lastPrevBubble.classList.remove('is-group-last', 'can-have-tail')
          lastPrevBubble.querySelector('.bubble-tail')?.remove()
        }
      } else if (prevGroupEl.classList.contains('bubbles-group-last')) {
        group.style.marginTop = '6px'
      }
    }

    // ── 다음 그룹과의 간격 ──
    if (!isGroupLast) {
      var nextGroupEl = group.nextElementSibling
      if (nextGroupEl && nextGroupEl.classList.contains('bubbles-group') &&
          !nextGroupEl.classList.contains('teledit-injected-group')) {
        var firstNextBubble = nextGroupEl.querySelector('.bubble:first-child')
        if (firstNextBubble) {
          firstNextBubble.classList.remove('is-group-first')
        }
      }
    }
  }

  return true
}
// ── 채널 말풍선 DOM 주입 — 오케스트레이터 ────────────────────────────────────

function insertBubble(text, pos, forceInsert) {
  if (!isChannelView()) {
    console.log('[Teledit] 채널이 아닌 채팅 — 스킵')
    return false
  }

  var posId   = pos ? String(pos.id) : null
  var fakeMid = 'teledit-' + (posId || Date.now())
  if (document.querySelector('[data-mid="' + fakeMid + '"]')) return false

  // 진입 시간
  var entryTs = pos && pos.entryTime
    ? Math.floor(new Date(pos.entryTime).getTime() / 1000)
    : Math.floor(Date.now() / 1000)

  // 미래 시간 스킵
  var nowTs = Math.floor(Date.now() / 1000)
  if (entryTs > nowTs) return false

  var template = document.querySelector('.bubble.channel-post.with-replies:not(.teledit-injected)')
  if (!template) { console.warn('[Teledit] 템플릿 없음'); return false }
  var bubble = template.cloneNode(true)

  // 시간 문자열 생성
  var d = pos && pos.entryTime ? new Date(pos.entryTime) : new Date()
  var existingTimeEl = document.querySelector('.bubble.channel-post:not(.teledit-injected) .time .i18n')
  var existingTimeText = existingTimeEl ? existingTimeEl.textContent.trim() : ''
  var timeStr
  if (existingTimeText) {
    var hours = d.getHours()
    var mins = d.getMinutes().toString().padStart(2, '0')
    var h12 = hours === 0 ? 12 : hours > 12 ? hours - 12 : hours
    var ap = hours < 12 ? existingTimeText.match(/[Aa][Mm]/)?.[0] || 'AM' : existingTimeText.match(/[Pp][Mm]/)?.[0] || 'PM'
    var hStr = h12.toString().padStart(2, '0')
    var ampmFirst = /^[APap][Mm]\s/.test(existingTimeText)
    timeStr = ampmFirst ? (ap + ' ' + hStr + ':' + mins) : (hStr + ':' + mins + ' ' + ap)
  } else {
    timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
  }
  var titleStr = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) +
    ', ' + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' })

  // 그룹 경계 판단
  var groupInfo = _getGroupInfo(entryTs)
  var isGroupFirst = groupInfo.isGroupFirst
  var isGroupLast  = groupInfo.isGroupLast

  // 기본 속성
  bubble.setAttribute('data-mid', fakeMid)
  bubble.setAttribute('data-timestamp', String(entryTs))
  bubble.dataset.status = pos?.status || 'OPEN'
  bubble.classList.add('teledit-injected')
  bubble.classList.toggle('is-group-first', isGroupFirst)
  bubble.classList.toggle('is-group-last', isGroupLast)

  // 편집 이중 시간 제거
  bubble.querySelectorAll('.time-edited').forEach(function(el) { el.remove() })

  // 메시지 텍스트 교체
  var msgSpan = bubble.querySelector('.translatable-message')
  if (msgSpan) {
    while (msgSpan.firstChild) msgSpan.removeChild(msgSpan.firstChild)
    msgSpan.appendChild(document.createTextNode(text))
  }

  // ── 리액션 (bubble-reactions.js) ──
  var rxResult = _buildBubbleReactions(bubble, pos, posId, entryTs)

  // 불필요한 원본 요소 제거
  bubble.querySelector('.reply')?.remove()
  bubble.querySelector('.webpage')?.remove()

  // ── profit1 이미지 처리 ──
  // 단순화: .message 유지 (텍스트만 비움), .attachment를 .message 앞에 추가
  // reactions/time은 .message 안에 그대로 둠 (Telegram 기본 구조)
  var _isProfit1 = pos && pos._messageType === 'profit1'
  var _parentPosId = pos && pos._parentPosId ? pos._parentPosId : null
  if (_isProfit1 && _parentPosId) {
    var _bcEl = bubble.querySelector('.bubble-content')

    // 1. .message에서 .time 미리 추출 (복사), 그 다음 .message 제거
    var _msgDiv = bubble.querySelector('.message')
    var _clonedTime = _msgDiv ? _msgDiv.querySelector('.time')?.cloneNode(true) : null
    if (_msgDiv) _msgDiv.remove()

    // 2. .attachment 생성 (bc 첫 번째 자식)
    var _attachment = bubble.querySelector('.attachment')
    if (!_attachment) {
      _attachment = document.createElement('div')
      _attachment.className = 'attachment media-container'
      if (_bcEl) _bcEl.insertBefore(_attachment, _bcEl.firstChild)
    }
    while (_attachment.firstChild) _attachment.removeChild(_attachment.firstChild)

    // 이미지 플레이스홀더
    var _placeholder = document.createElement('img')
    _placeholder.className = 'media-photo'
    _placeholder.src = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="362" height="500"><rect fill="#0d1117" width="362" height="500"/></svg>')
    _placeholder.style.cssText = 'width:362px;height:500px;display:block;'
    _attachment.appendChild(_placeholder)
    _attachment.style.cssText = 'width:362px;position:relative;overflow:hidden;'

    // 3. 시간/뷰수 — 기존 .time 요소를 그대로 복사해 absolute 오버레이로 사용
    var _timeOverlay = _clonedTime || document.createElement('div')
    _timeOverlay.className = (_timeOverlay.className || '') + ' teledit-time-overlay'
    _timeOverlay.style.cssText = 'position:absolute;bottom:4px;right:4px;z-index:2;'
    // .time-inner에 Telegram 원본 포토 오버레이 CSS 직접 적용
    var _timeInner = _timeOverlay.querySelector('.time-inner')
    if (_timeInner) {
      _timeInner.style.cssText = 'background:#00000059!important;border-radius:10px;height:18px;padding:0 5px;color:#fff!important;display:flex;align-items:center;'
    }
    _attachment.appendChild(_timeOverlay)

    // 4. 핵심 클래스 — Telegram 실제 이미지 전용 포스트 클래스
    bubble.classList.add('photo', 'is-message-empty')
    bubble.classList.remove('has-webpage', 'video', 'just-media')
    if (_bcEl) _bcEl.style.maxWidth = 'min(100%, 420px)'

    // bubble flex를 column으로 — reactions가 아래로
    bubble.style.flexDirection = 'column'
    bubble.style.alignItems = 'flex-start'

    // 5. reactions: .time 제거
    var _rxEl = rxResult.reactionsEl
    if (_rxEl) {
      var _rxTime = _rxEl.querySelector('.time')
      if (_rxTime) _rxTime.remove()
    }

    // 6. 이미지 fetch + 로드 후 크기 조정
    fetchProfitCardImage(_parentPosId).then(function(imgUrl) {
      if (imgUrl && _placeholder.parentElement) {
        _placeholder.onload = function() {
          _placeholder.style.cssText = 'width:100%;height:auto;display:block;'
          var h = _placeholder.naturalHeight * (_attachment.offsetWidth / _placeholder.naturalWidth)
          _attachment.style.setProperty('max-height', 'none', 'important')
          _attachment.style.setProperty('height', Math.round(h) + 'px', 'important')
        }
        _placeholder.src = imgUrl
      }
    })
  } else {
    bubble.querySelector('.attachment')?.remove()
    bubble.classList.remove('has-webpage', 'single-media', 'photo', 'video', 'just-media')
  }

  // 버블 테일
  if (!isGroupLast) {
    bubble.classList.remove('can-have-tail')
    bubble.querySelector('.bubble-tail')?.remove()
  }

  // ── 그룹/삽입 (bubble-groups.js) ──
  var group = document.createElement('div')
  group.className = 'bubbles-group teledit-injected-group'
  var insertResult = _insertBubbleIntoDOM(bubble, group, entryTs, pos, posId, isGroupFirst, isGroupLast, forceInsert)
  if (!insertResult) return false

  if (pos) injectedBubbles.set(fakeMid, { text: text, pos: pos })

  // 시간/뷰 업데이트
  bubble.querySelectorAll('.post-views').forEach(function(el) { el.textContent = String(rxResult.viewCount) })
  bubble.querySelectorAll('.time .i18n').forEach(function(el) { el.textContent = timeStr })
  bubble.querySelectorAll('.time-inner').forEach(function(el) { el.title = titleStr })

  // profit1: 시간/뷰수 직접 설정 + reactions 이동
  if (_isProfit1) {
    var _ov = bubble.querySelector('.teledit-time-overlay')
    if (_ov) {
      var _ovViews = _ov.querySelector('.post-views')
      var _ovTime = _ov.querySelector('.i18n')
      if (_ovViews) _ovViews.textContent = String(rxResult.viewCount)
      if (_ovTime) _ovTime.textContent = timeStr
    }

    // reactions를 bubble-content-wrapper 뒤에 (Telegram 구조 기반)
    if (rxResult.reactionsEl) {
      rxResult.reactionsEl.remove()
      var _bcw = bubble.querySelector('.bubble-content-wrapper')
      if (_bcw && _bcw.nextSibling) bubble.insertBefore(rxResult.reactionsEl, _bcw.nextSibling)
      else bubble.appendChild(rxResult.reactionsEl)
    }
  }

  // 클릭 인터셉터
  if (rxResult.reactionsEl) _attachReactionInterceptor(rxResult.reactionsEl, rxResult.reactionData, posId)

  // ── 댓글 영역 (bubble-replies.js) ──
  _buildRepliesFooter(bubble, pos, posId)

  return true
}

// ── 스크롤 복귀 후 재주입 ─────────────────────────────────────────────────────
function reinjectBubbles() {
  if (!isChannelView()) return
  document.querySelectorAll('.teledit-date-sep').forEach(function(sep) {
    if (!sep.nextElementSibling?.classList.contains('teledit-injected-group')) sep.remove()
  })
  var sorted = [...injectedBubbles.entries()]
    .sort(function(a, b) {
      var tsA = a[1].pos?.entryTime ? new Date(a[1].pos.entryTime).getTime() : 0
      var tsB = b[1].pos?.entryTime ? new Date(b[1].pos.entryTime).getTime() : 0
      return tsA - tsB
    })
  for (var k = 0; k < sorted.length; k++) {
    var fakeMid = sorted[k][0]
    if (!document.querySelector('[data-mid="' + fakeMid + '"]')) {
      insertBubble(sorted[k][1].text, sorted[k][1].pos)
    }
  }
  if (pendingBubbles.size) {
    var pendingSorted = [...pendingBubbles.values()]
      .sort(function(a, b) { return new Date(a.pos.entryTime) - new Date(b.pos.entryTime) })
    for (var i = 0; i < pendingSorted.length; i++) {
      if (insertBubble(pendingSorted[i].text, pendingSorted[i].pos)) {
        pendingBubbles.delete(String(pendingSorted[i].pos.id))
      }
    }
  }
}
// ── content.js — 수동 삽입 + 스크롤 자동 삽입 ─────────────────────────────────

function _dbg(msg) {
  console.log('[Teledit] ' + msg)
  var el = document.getElementById('teledit-dbg')
  if (!el) {
    el = document.createElement('div')
    el.id = 'teledit-dbg'
    el.style.cssText = 'position:fixed;bottom:8px;right:8px;z-index:99999;background:rgba(0,0,0,0.85);color:#5eacd3;font-size:11px;padding:6px 10px;border-radius:6px;font-family:monospace;max-width:350px;pointer-events:none;'
    document.body.appendChild(el)
  }
  el.textContent = '[Teledit] ' + msg
}

function injectPageScript() {
  if (window.__teleditPageScriptInjected) return
  window.__teleditPageScriptInjected = true
  try {
    var script = document.createElement('script')
    script.src = chrome.runtime.getURL('page-script.js')
    script.onload = function() { script.remove() }
    script.onerror = function() { script.remove() }
    ;(document.head || document.documentElement).appendChild(script)
  } catch (e) {}
}

function injectStyles() {
  if (document.getElementById('teledit-styles')) return
  var style = document.createElement('style')
  style.id = 'teledit-styles'
  style.textContent = [
    '@keyframes teledit-sticker-pop{0%{transform:scale(1)}25%{transform:scale(1.55) rotate(-8deg)}60%{transform:scale(0.85) rotate(4deg)}85%{transform:scale(1.1)}100%{transform:scale(1)}}',
    '@keyframes teledit-float-up{0%{opacity:1;transform:translateY(0) scale(1)}60%{opacity:.8;transform:translateY(-32px) scale(1.3)}100%{opacity:0;transform:translateY(-56px) scale(2)}}',
    // stacked-avatars: 이제 직접 관리 (숨기지 않음)
    '.teledit-injected .replies-short{display:none!important}',
    // avatar-like: replies 아바타에 사용되므로 숨기지 않음
    // 날짜 구분선: Telegram K 실제 CSS 값 재현
    '.teledit-date-sep{text-align:center;margin:5px auto 5px!important;padding:0}',
    '.teledit-date-sep .teledit-date-label{display:inline-flex;background:var(--message-highlighting-color, rgba(0,0,0,0.35))!important;padding:4.5px 10px;border-radius:14px;color:#fff;font-size:15px;font-weight:500;line-height:20px}',
  ].join('')
  document.head.appendChild(style)
}

// ── 댓글 작성자 캐시 ─────────────────────────────────────────────────────────

async function fetchCommentAuthors(posId) {
  if (_commentAuthorsCache.has(posId)) return _commentAuthorsCache.get(posId)
  try {
    var settings = await loadSettings()
    if (!settings.token) return null
    var res = await safeFetch(
      SERVER_URL + '/api/positions/' + posId + '/comments',
      { Authorization: 'Bearer ' + settings.token },
    )
    if (!res.ok || !res.data || !res.data.comments) return null
    // messageType별 작성자 그룹핑
    var byType = {}
    res.data.comments.forEach(function(c) {
      if (!byType[c.messageType]) byType[c.messageType] = []
      byType[c.messageType].push(c.authorName)
    })
    _commentAuthorsCache.set(posId, byType)
    return byType
  } catch (e) { return null }
}

// ── 포지션 1개 → 상황별 채널 포스트 삽입 ─────────────────────────────────────
function insertPositionMessages(pos, forceInsert, commentAuthors) {
  var posId = String(pos.id)
  var messages = buildPositionMessages(pos)

  if (!messages || messages.length === 0) {
    return insertBubble(buildAutoMessage(pos), pos, forceInsert) ? 1 : 0
  }

  var inserted = 0
  // postEntry1/2/3 → postEntry, postClose1/2/3 → close (DB에 없는 서브타입은 부모 타입 작성자 사용)
  var _authorTypeMap = {
    postEntry1: 'postEntry', postEntry2: 'postEntry', postEntry3: 'postEntry',
    postClose1: 'close', postClose2: 'close', postClose3: 'close',
  }

  for (var i = 0; i < messages.length; i++) {
    var msg = messages[i]
    // 해당 messageType의 댓글 작성자 (DB에서 가져온 것)
    var _lookupType = _authorTypeMap[msg.type] || msg.type
    var authors = commentAuthors && commentAuthors[_lookupType] ? commentAuthors[_lookupType] : null
    var virtualPos = {
      id: msg.id,
      entryTime: msg.entryTime,
      symbol: pos.symbol,
      side: pos.side,
      leverage: pos.leverage,
      status: pos.status,
      entryPrice: pos.entryPrice,
      closedPrice: pos.closedPrice,
      closedAt: pos.closedAt,
      pnl: pos.pnl,
      amount: pos.amount,
      quantity: pos.quantity,
      entryFee: pos.entryFee,
      inputPrice: pos.inputPrice,
      closeReason: pos.closeReason,
      _messageType: msg.type,
      _parentPosId: posId,
      _commentAuthors: authors,  // DB 작성자
      _commentCount: msg.commentCount != null ? msg.commentCount : null,
    }
    if (insertBubble(msg.text, virtualPos, forceInsert)) inserted++
  }
  return inserted
}

// ── 채널 변경 감지 + 상태 초기화 ─────────────────────────────────────────────

var _currentPeer = ''

function _getCurrentPeer() {
  return window.location.hash + '|' + window.location.pathname
}

function _clearChannelState() {
  injectedBubbles.clear()
  pendingBubbles.clear()
  bubbleDataCache.clear()
  _replyDataCache.clear()
  _commentAuthorsCache.clear()
  _insertedPositions = []
  if (_scrollObserver) {
    _scrollObserver.disconnect()
    _scrollObserver = null
  }
  _currentPeer = _getCurrentPeer()
  console.log('[Teledit] 채널 변경 감지 → 상태 초기화')
}

// ── 스크롤 감지 → pending 자동 삽입 ─────────────────────────────────────────
// MutationObserver 대신 scroll 이벤트 사용 — Telegram DOM 변경에 의한 무한루프 방지

function startScrollObserver() {
  if (_scrollObserver) return

  var _tryAttach = function() {
    var scrollEl = document.querySelector('.bubbles .scrollable-y')
    if (!scrollEl) return false

    var _onScroll = function() {
      clearTimeout(_scrollDebounce)
      _scrollDebounce = setTimeout(function() {
        if (!isChannelView()) return

        // 채널 변경 감지 → 상태 초기화 후 중단
        var peer = _getCurrentPeer()
        if (peer !== _currentPeer) {
          _clearChannelState()
          return
        }

        var distFromBottom = scrollEl.scrollHeight - scrollEl.scrollTop - scrollEl.clientHeight
        var atBot = distFromBottom < 150

        // 재삽입/pending 처리는 맨 아래에 있을 때만 — 스크롤 업 중 삽입 시 점프 방지
        if (!atBot) return

        // 스크롤 위치 보존 (삽입으로 인한 점프 방지)
        var _savedScrollTop = scrollEl.scrollTop
        var _savedScrollHeight = scrollEl.scrollHeight

        // 1) DOM에서 사라진 injectedBubbles 재삽입 (Telegram 가상화 대응)
        var reinjected = 0
        var sortedInjected = [...injectedBubbles.entries()]
          .sort(function(a, b) {
            var tsA = a[1].pos?.entryTime ? new Date(a[1].pos.entryTime).getTime() : 0
            var tsB = b[1].pos?.entryTime ? new Date(b[1].pos.entryTime).getTime() : 0
            return tsA - tsB
          })
        for (var k = 0; k < sortedInjected.length; k++) {
          var fakeMid = sortedInjected[k][0]
          if (!document.querySelector('[data-mid="' + fakeMid + '"]')) {
            var entry = sortedInjected[k][1]
            if (insertBubble(entry.text, entry.pos)) reinjected++
          }
        }

        // 2) pending 재시도
        var retried = 0
        var sorted = [...pendingBubbles.values()]
          .sort(function(a, b) { return new Date(a.pos.entryTime) - new Date(b.pos.entryTime) })
        for (var i = 0; i < sorted.length; i++) {
          if (insertBubble(sorted[i].text, sorted[i].pos)) {
            pendingBubbles.delete(String(sorted[i].pos.id))
            retried++
          }
        }

        // 스크롤 위치 복원 — 삽입으로 인해 위치가 바뀐 경우 보정
        var _heightDiff = scrollEl.scrollHeight - _savedScrollHeight
        if (_heightDiff > 0 && scrollEl.scrollTop !== _savedScrollTop) {
          scrollEl.scrollTop = _savedScrollTop + _heightDiff
        }

        if (reinjected || retried) console.log('[Teledit] 스크롤 → reinject:' + reinjected + ' pending:' + retried)
      }, 200)
    }

    scrollEl.addEventListener('scroll', _onScroll, { passive: true })
    _scrollObserver = {
      disconnect: function() { scrollEl.removeEventListener('scroll', _onScroll) },
    }
    console.log('[Teledit] 스크롤 감지 시작 (pending: ' + pendingBubbles.size + ')')
    return true
  }

  // 스크롤 컨테이너가 아직 없으면 최대 4초간 재시도
  if (!_tryAttach()) {
    _currentPeer = _getCurrentPeer()
    var _attempts = 0
    var _findInterval = setInterval(function() {
      if (_tryAttach() || ++_attempts > 20) clearInterval(_findInterval)
    }, 200)
  } else {
    _currentPeer = _getCurrentPeer()
  }
}

// ── 팝업 메시지 수신 ─────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {
  if (msg.action === 'getStatus') {
    sendResponse({ initialized: !!window.__teleditLoaded, isChannelView: isChannelView() })
    return true
  }

  if (msg.action === 'insertPositions') {
    (async function() {
      try {
        if (!isChannelView()) {
          sendResponse({ error: '채널 뷰가 아닙니다' })
          return
        }

        var ids = new Set(msg.positionIds || [])
        if (ids.size === 0) {
          sendResponse({ error: '선택된 포지션 없음' })
          return
        }

        var settings = await loadSettings()
        if (!settings.token) {
          sendResponse({ error: '로그인 필요' })
          return
        }

        await fetchUserSettings()

        // 채널 변경 시 기존 상태 초기화 후 새로 삽입
        var peer = _getCurrentPeer()
        if (peer !== _currentPeer && _currentPeer !== '') {
          _clearChannelState()
        }
        _currentPeer = peer

        var fetched = await fetchPositions(SERVER_URL, settings.token)
        if (!fetched || !fetched.length) {
          sendResponse({ error: '포지션 로드 실패' })
          return
        }

        // 선택된 포지션 시간순 삽입
        var toInsert = fetched
          .filter(function(p) { return ids.has(String(p.id)) })
          .sort(function(a, b) { return new Date(a.entryTime) - new Date(b.entryTime) })

        // 팝업에서 명시적으로 선택한 포지션 → 초기 삽입은 forceInsert=true
        // (스크롤 핸들러의 재삽입은 forceInsert=false로 범위 검사 적용)

        // 각 포지션의 댓글 작성자 프리페치
        var commentAuthorsByPos = {}
        await Promise.all(toInsert.map(async function(p) {
          commentAuthorsByPos[p.id] = await fetchCommentAuthors(String(p.id))
        }))

        var totalInserted = 0
        for (var i = 0; i < toInsert.length; i++) {
          var posAuthors = commentAuthorsByPos[toInsert[i].id] || null
          totalInserted += insertPositionMessages(toInsert[i], true, posAuthors)
        }

        // 포지션 데이터 보관 (스크롤 시 재시도용)
        _insertedPositions = toInsert

        // 스크롤 감지 시작 (reinject + pending 처리)
        startScrollObserver()

        var pendingCount = pendingBubbles.size
        sendResponse({
          inserted: totalInserted,
          pending: pendingCount,
        })
      } catch (e) {
        sendResponse({ error: e.message || '삽입 실패' })
      }
    })()
    return true
  }
})

// ── 초기화 ───────────────────────────────────────────────────────────────────
async function init() {
  if (window.__teleditLoaded) return
  window.__teleditLoaded = true
  try {
    injectPageScript()
    injectStyles()
    var settings = await loadSettings()
    if (settings.token) {
      await fetchUserSettings()
      fetchPositions(SERVER_URL, settings.token).catch(function() {}) // 프리페치
    }
    _dbg('준비 완료')
    setTimeout(function() {
      var el = document.getElementById('teledit-dbg')
      if (el) el.remove()
    }, 3000)
  } catch (e) {
    console.error('[Teledit] init 실패:', e)
    window.__teleditLoaded = false
  }
}

chrome.storage.onChanged.addListener(function(changes) {
  if ('token' in changes) {
    window.__teleditLoaded = false
    init()
  }
})

init()
