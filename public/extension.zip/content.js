// ── content.js — 수동 삽입 + 스크롤 자동 삽입 ─────────────────────────────────

function _dbg(msg) {
  console.log('[Teledit] ' + msg)
  var el = document.getElementById('teledit-dbg')
  if (!el) {
    el = document.createElement('div')
    el.id = 'teledit-dbg'
    el.style.cssText = 'position:fixed;bottom:8px;right:8px;z-index:99999;background:rgba(0,0,0,0.85);color:#5eacd3;font-size:11px;padding:6px 10px;border-radius:6px;font-family:monospace;max-width:350px;pointer-events:none;'
    document.body.appendChild(el)
  }
  el.textContent = '[Teledit] ' + msg
}

function injectPageScript() {
  if (window.__teleditPageScriptInjected) return
  window.__teleditPageScriptInjected = true
  try {
    var script = document.createElement('script')
    script.src = chrome.runtime.getURL('page-script.js')
    script.onload = function() { script.remove() }
    script.onerror = function() { script.remove() }
    ;(document.head || document.documentElement).appendChild(script)
  } catch (e) {}
}

function injectStyles() {
  if (document.getElementById('teledit-styles')) return
  var style = document.createElement('style')
  style.id = 'teledit-styles'
  style.textContent = [
    '@keyframes teledit-sticker-pop{0%{transform:scale(1)}25%{transform:scale(1.55) rotate(-8deg)}60%{transform:scale(0.85) rotate(4deg)}85%{transform:scale(1.1)}100%{transform:scale(1)}}',
    '@keyframes teledit-float-up{0%{opacity:1;transform:translateY(0) scale(1)}60%{opacity:.8;transform:translateY(-32px) scale(1.3)}100%{opacity:0;transform:translateY(-56px) scale(2)}}',
    // stacked-avatars: 이제 직접 관리 (숨기지 않음)
    '.teledit-injected .replies-short{display:none!important}',
    // avatar-like: replies 아바타에 사용되므로 숨기지 않음
    // 날짜 구분선: Telegram K 실제 CSS 값 재현
    '.teledit-date-sep{text-align:center;margin:5px auto 5px!important;padding:0}',
    '.teledit-date-sep .teledit-date-label{display:inline-flex;background:var(--message-highlighting-color, rgba(0,0,0,0.35))!important;padding:4.5px 10px;border-radius:14px;color:#fff;font-size:15px;font-weight:500;line-height:20px}',
  ].join('')
  document.head.appendChild(style)
}

// ── 댓글 작성자 캐시 ─────────────────────────────────────────────────────────

async function fetchCommentAuthors(posId) {
  if (_commentAuthorsCache.has(posId)) return _commentAuthorsCache.get(posId)
  try {
    var settings = await loadSettings()
    if (!settings.token) return null
    var res = await safeFetch(
      SERVER_URL + '/api/positions/' + posId + '/comments',
      { Authorization: 'Bearer ' + settings.token },
    )
    if (!res.ok || !res.data || !res.data.comments) return null
    // messageType별 작성자 그룹핑
    var byType = {}
    res.data.comments.forEach(function(c) {
      if (!byType[c.messageType]) byType[c.messageType] = []
      byType[c.messageType].push(c.authorName)
    })
    _commentAuthorsCache.set(posId, byType)
    return byType
  } catch (e) { return null }
}

// ── 포지션 1개 → 상황별 채널 포스트 삽입 ─────────────────────────────────────
function insertPositionMessages(pos, forceInsert, commentAuthors) {
  var posId = String(pos.id)
  var messages = buildPositionMessages(pos)

  if (!messages || messages.length === 0) {
    return insertBubble(buildAutoMessage(pos), pos, forceInsert) ? 1 : 0
  }

  var inserted = 0
  for (var i = 0; i < messages.length; i++) {
    var msg = messages[i]
    // 해당 messageType의 댓글 작성자 (DB에서 가져온 것)
    var authors = commentAuthors && commentAuthors[msg.type] ? commentAuthors[msg.type] : null
    var virtualPos = {
      id: msg.id,
      entryTime: msg.entryTime,
      symbol: pos.symbol,
      side: pos.side,
      leverage: pos.leverage,
      status: pos.status,
      entryPrice: pos.entryPrice,
      closedPrice: pos.closedPrice,
      closedAt: pos.closedAt,
      pnl: pos.pnl,
      amount: pos.amount,
      quantity: pos.quantity,
      entryFee: pos.entryFee,
      inputPrice: pos.inputPrice,
      closeReason: pos.closeReason,
      _messageType: msg.type,
      _parentPosId: posId,
      _commentAuthors: authors,  // DB 작성자
    }
    if (insertBubble(msg.text, virtualPos, forceInsert)) inserted++
  }
  return inserted
}

// ── 채널 변경 감지 + 상태 초기화 ─────────────────────────────────────────────

var _currentPeer = ''

function _getCurrentPeer() {
  return window.location.hash + '|' + window.location.pathname
}

function _clearChannelState() {
  injectedBubbles.clear()
  pendingBubbles.clear()
  bubbleDataCache.clear()
  _replyDataCache.clear()
  _commentAuthorsCache.clear()
  _insertedPositions = []
  if (_scrollObserver) {
    _scrollObserver.disconnect()
    _scrollObserver = null
  }
  _currentPeer = _getCurrentPeer()
  console.log('[Teledit] 채널 변경 감지 → 상태 초기화')
}

// ── 스크롤 감지 → pending 자동 삽입 ─────────────────────────────────────────
// MutationObserver 대신 scroll 이벤트 사용 — Telegram DOM 변경에 의한 무한루프 방지

function startScrollObserver() {
  if (_scrollObserver) return

  var _tryAttach = function() {
    var scrollEl = document.querySelector('.bubbles .scrollable-y')
    if (!scrollEl) return false

    var _onScroll = function() {
      clearTimeout(_scrollDebounce)
      _scrollDebounce = setTimeout(function() {
        if (!isChannelView()) return

        // 채널 변경 감지 → 상태 초기화 후 중단
        var peer = _getCurrentPeer()
        if (peer !== _currentPeer) {
          _clearChannelState()
          return
        }

        var distFromBottom = scrollEl.scrollHeight - scrollEl.scrollTop - scrollEl.clientHeight
        var atBot = distFromBottom < 150

        // 1) DOM에서 사라진 injectedBubbles 재삽입 (Telegram 가상화 대응)
        var reinjected = 0
        var sortedInjected = [...injectedBubbles.entries()]
          .sort(function(a, b) {
            var tsA = a[1].pos?.entryTime ? new Date(a[1].pos.entryTime).getTime() : 0
            var tsB = b[1].pos?.entryTime ? new Date(b[1].pos.entryTime).getTime() : 0
            return tsA - tsB
          })
        for (var k = 0; k < sortedInjected.length; k++) {
          var fakeMid = sortedInjected[k][0]
          if (!document.querySelector('[data-mid="' + fakeMid + '"]')) {
            var entry = sortedInjected[k][1]
            if (insertBubble(entry.text, entry.pos)) reinjected++
          }
        }

        // 2) pending 재시도
        var retried = 0
        var sorted = [...pendingBubbles.values()]
          .sort(function(a, b) { return new Date(a.pos.entryTime) - new Date(b.pos.entryTime) })
        for (var i = 0; i < sorted.length; i++) {
          if (insertBubble(sorted[i].text, sorted[i].pos)) {
            pendingBubbles.delete(String(sorted[i].pos.id))
            retried++
          }
        }

        // 3) 포지션 재시도 (맨 아래에 있을 때만)
        if (atBot) {
          for (var j = 0; j < _insertedPositions.length; j++) {
            insertPositionMessages(_insertedPositions[j], true)
          }
        }

        if (reinjected || retried) console.log('[Teledit] 스크롤 → reinject:' + reinjected + ' pending:' + retried)
      }, 200)
    }

    scrollEl.addEventListener('scroll', _onScroll, { passive: true })
    _scrollObserver = {
      disconnect: function() { scrollEl.removeEventListener('scroll', _onScroll) },
    }
    console.log('[Teledit] 스크롤 감지 시작 (pending: ' + pendingBubbles.size + ')')
    return true
  }

  // 스크롤 컨테이너가 아직 없으면 최대 4초간 재시도
  if (!_tryAttach()) {
    _currentPeer = _getCurrentPeer()
    var _attempts = 0
    var _findInterval = setInterval(function() {
      if (_tryAttach() || ++_attempts > 20) clearInterval(_findInterval)
    }, 200)
  } else {
    _currentPeer = _getCurrentPeer()
  }
}

// ── 팝업 메시지 수신 ─────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {
  if (msg.action === 'getStatus') {
    sendResponse({ initialized: !!window.__teleditLoaded, isChannelView: isChannelView() })
    return true
  }

  if (msg.action === 'insertPositions') {
    (async function() {
      try {
        if (!isChannelView()) {
          sendResponse({ error: '채널 뷰가 아닙니다' })
          return
        }

        var ids = new Set(msg.positionIds || [])
        if (ids.size === 0) {
          sendResponse({ error: '선택된 포지션 없음' })
          return
        }

        var settings = await loadSettings()
        if (!settings.token) {
          sendResponse({ error: '로그인 필요' })
          return
        }

        await fetchUserSettings()

        // 채널 변경 시 기존 상태 초기화 후 새로 삽입
        var peer = _getCurrentPeer()
        if (peer !== _currentPeer && _currentPeer !== '') {
          _clearChannelState()
        }
        _currentPeer = peer

        var fetched = await fetchPositions(SERVER_URL, settings.token)
        if (!fetched || !fetched.length) {
          sendResponse({ error: '포지션 로드 실패' })
          return
        }

        // 선택된 포지션 시간순 삽입
        var toInsert = fetched
          .filter(function(p) { return ids.has(String(p.id)) })
          .sort(function(a, b) { return new Date(a.entryTime) - new Date(b.entryTime) })

        // 맨 아래 여부 → forceInsert 결정
        var scrollEl = document.querySelector('.bubbles .scrollable-y')
        var atBottom = scrollEl && (scrollEl.scrollHeight - scrollEl.scrollTop - scrollEl.clientHeight < 150)

        // 각 포지션의 댓글 작성자 프리페치
        var commentAuthorsByPos = {}
        await Promise.all(toInsert.map(async function(p) {
          commentAuthorsByPos[p.id] = await fetchCommentAuthors(String(p.id))
        }))

        var totalInserted = 0
        for (var i = 0; i < toInsert.length; i++) {
          var posAuthors = commentAuthorsByPos[toInsert[i].id] || null
          totalInserted += insertPositionMessages(toInsert[i], atBottom, posAuthors)
        }

        // 포지션 데이터 보관 (스크롤 시 재시도용)
        _insertedPositions = toInsert

        // 스크롤 감지 시작 (reinject + pending 처리)
        startScrollObserver()

        var pendingCount = pendingBubbles.size
        sendResponse({
          inserted: totalInserted,
          pending: pendingCount,
        })
      } catch (e) {
        sendResponse({ error: e.message || '삽입 실패' })
      }
    })()
    return true
  }
})

// ── 초기화 ───────────────────────────────────────────────────────────────────
async function init() {
  if (window.__teleditLoaded) return
  window.__teleditLoaded = true
  try {
    injectPageScript()
    injectStyles()
    var settings = await loadSettings()
    if (settings.token) {
      await fetchUserSettings()
      fetchPositions(SERVER_URL, settings.token).catch(function() {}) // 프리페치
    }
    _dbg('준비 완료')
    setTimeout(function() {
      var el = document.getElementById('teledit-dbg')
      if (el) el.remove()
    }, 3000)
  } catch (e) {
    console.error('[Teledit] init 실패:', e)
    window.__teleditLoaded = false
  }
}

chrome.storage.onChanged.addListener(function(changes) {
  if ('token' in changes) {
    window.__teleditLoaded = false
    init()
  }
})

init()
