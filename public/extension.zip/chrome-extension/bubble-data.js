// ── 말풍선 데이터 계산 ───────────────────────────────────────────────────────

// ── 뷰 카운트 계산 (dom-helpers.js에서 이동) ────────────────────────────────
function _getViewsBetween(entryTs) {
  const bubbles = [...document.querySelectorAll('.bubble.channel-post[data-timestamp]:not(.teledit-injected)')]
    .sort((a, b) => parseInt(a.dataset.timestamp, 10) - parseInt(b.dataset.timestamp, 10))

  let before = null, after = null
  for (const b of bubbles) {
    const ts = parseInt(b.dataset.timestamp, 10)
    const v  = parseInt(b.querySelector('.post-views')?.textContent?.replace(/[^0-9]/g, '') || '0')
    if (ts <= entryTs) before = v
    else if (after === null) { after = v; break }
  }

  if (before !== null && after !== null) return _rand(Math.min(before, after), Math.max(before, after))
  if (before !== null) return _rand(Math.max(1, before - 8), before)
  if (after !== null)  return _rand(after + 5, after + 25)
  return _rand(450, 650)
}

// ── 댓글 수/작성자 캐시 (bug #3 수정) ───────────────────────────────────────
// reinject 시 _rand 재계산으로 아바타가 바뀌는 문제를 posId별 캐시로 해결
function _getReplyData(posId, msgType, dbAuthors, pos) {
  if (_replyDataCache.has(posId)) return _replyDataCache.get(posId)

  var commentCount = 0
  if (pos && pos._commentCount != null) {
    // DB 고정값 사용
    commentCount = pos._commentCount
  } else if (msgType && _userSettings && _userSettings.commentCounts) {
    // DB 값 없을 때 min/max 범위에서 랜덤 (폴백)
    var cc = _userSettings.commentCounts[msgType]
    if (cc && cc.max > 0) commentCount = _rand(cc.min, cc.max)
  }

  var avatarCount = Math.min(commentCount, 3)
  var authorNames = []
  if (dbAuthors && dbAuthors.length >= avatarCount) {
    for (var an = 0; an < avatarCount; an++) authorNames.push(dbAuthors[an])
  } else {
    var fallbackNames = ['해박','J','카파','금안','TP','HG','야미','준음']
    for (var fn = 0; fn < avatarCount; fn++) {
      authorNames.push(fallbackNames[(posId.charCodeAt(fn + 3) || fn) % fallbackNames.length])
    }
  }

  var data = { commentCount: commentCount, authorNames: authorNames }
  _replyDataCache.set(posId, data)
  return data
}
