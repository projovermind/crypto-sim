// ── 반응 클릭 인터셉터 ────────────────────────────────────────────────────────
// reactions-element.connectedCallback이 우리 div를 reaction-element 웹컴포넌트로
// 교체하므로, DOM 삽입 이후에 capture 리스너로 클릭을 가로채야 한다.

function _attachReactionInterceptor(reactionsEl, reactionData, posId) {
  reactionsEl.addEventListener('click', (e) => {
    const reactionEl = e.target.closest('reaction-element')
                    || e.target.closest('.reaction.reaction-block')
    if (!reactionEl || !reactionsEl.contains(reactionEl)) return

    e.stopImmediatePropagation()
    e.preventDefault()

    const allReactionEls = [...reactionsEl.querySelectorAll('reaction-element, .reaction.reaction-block')]
    const idx = allReactionEls.indexOf(reactionEl)
    if (idx === -1) return

    const isChosen  = reactionEl.classList.contains('is-chosen')
    const counter   = reactionEl.querySelector('.reaction-counter')
    const img       = reactionEl.querySelector('.media-sticker')
    const blobSrc   = img?.src
    const emoticon  = REACTION_EMOTICONS[idx]
    const rect      = reactionEl.getBoundingClientRect()

    if (!isChosen) {
      reactionEl.classList.add('animating')
      void reactionEl.offsetHeight
      reactionEl.classList.add('is-chosen')
      setTimeout(() => reactionEl.classList.remove('animating'), 320)
      if (counter) counter.textContent = String(parseInt(counter.textContent) + 1)

      // Telegram around_animation (page context lottie)
      if (emoticon) {
        const containerId = 'teledit-anim-' + Date.now()
        const animContainer = document.createElement('div')
        animContainer.id = containerId
        Object.assign(animContainer.style, {
          position: 'fixed',
          left: (rect.left + rect.width  / 2 - 40) + 'px',
          top:  (rect.top  + rect.height / 2 - 40) + 'px',
          width: '80px', height: '80px',
          zIndex: '99999', pointerEvents: 'none',
        })
        document.body.appendChild(animContainer)
        document.dispatchEvent(new CustomEvent('teledit-play-reaction', {
          detail: { containerId, emoticon },
        }))
      }

      // CSS 스티커 팝
      if (img) {
        img.style.animation = 'none'
        void img.offsetHeight
        img.style.animation = 'teledit-sticker-pop 0.42s ease'
        setTimeout(() => { img.style.animation = '' }, 420)
      }

      // 플로팅 이펙트
      if (blobSrc) {
        const floater = document.createElement('div')
        Object.assign(floater.style, {
          position: 'fixed',
          left: (rect.left + rect.width  / 2 - 14) + 'px',
          top:  (rect.top - 8) + 'px',
          width: '28px', height: '28px',
          zIndex: '99999', pointerEvents: 'none',
          animation: 'teledit-float-up 0.65s ease forwards',
        })
        const fImg = document.createElement('img')
        fImg.src = blobSrc
        fImg.style.cssText = 'width:100%;height:100%;object-fit:contain;'
        floater.appendChild(fImg)
        document.body.appendChild(floater)
        setTimeout(() => floater.remove(), 750)
      }

    } else {
      reactionEl.classList.add('backwards', 'animating')
      void reactionEl.offsetHeight
      reactionEl.classList.remove('is-chosen')
      setTimeout(() => reactionEl.classList.remove('backwards', 'animating'), 320)
      if (counter) counter.textContent = String(parseInt(counter.textContent) - 1)
    }

    // 캐시 갱신
    if (posId) {
      const data = bubbleDataCache.get(posId)
      if (data && data.reactions[idx]) {
        data.reactions[idx].count  = parseInt(counter?.textContent || '0')
        data.reactions[idx].chosen = reactionEl.classList.contains('is-chosen')
      }
    }
  }, true)
}
