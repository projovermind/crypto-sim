// ── 댓글 영역 렌더링 ────────────────────────────────────────────────────────

function _buildRepliesFooter(bubble, pos, posId) {
  var repliesRe = bubble.querySelector('replies-element')
  if (!repliesRe) return

  // connectedCallback 데이터 로드 차단
  repliesRe.removeAttribute('data-post-key')

  // 댓글 수/작성자: 캐시에서 가져오기 (bug #3 수정 — 안정적 아바타)
  var _msgType = pos && pos._messageType ? pos._messageType : null
  var _dbAuthors = pos && pos._commentAuthors ? pos._commentAuthors : null
  var replyData = _getReplyData(posId, _msgType, _dbAuthors, pos)
  var _commentCount = replyData.commentCount
  var authorNames = replyData.authorNames

  // 채널 아바타가 설정돼 있으면 첫 번째 아바타로 사용
  if (_commentCount > 0 && _userSettings && _userSettings.channelAvatarUrl && authorNames.length < 3) {
    authorNames = ['__channel__'].concat(authorNames).slice(0, 3)
  }

  // Telegram K 아바타 색상
  var _tgColors = ['red', 'green', 'violet', 'cyan', 'blue', 'pink', 'orange']

  var _cleanReplies = function(el) {
    // 기존 아바타/짧은답장 제거
    el.querySelectorAll('.stacked-avatars, .replies-short').forEach(function(c) { c.remove() })

    if (_commentCount === 0) {
      // 아이콘 항상 강제 보장: 기존 것 모두 제거 후 새로 삽입
      el.querySelectorAll('.replies-footer-icon-comments').forEach(function(c) { c.remove() })
      var footerInner = el.querySelector('.replies-footer')
      if (footerInner) {
        var icon = document.createElement('span')
        icon.className = 'tgico replies-footer-icon replies-footer-icon-comments'
        footerInner.insertBefore(icon, footerInner.firstChild)
      }
    } else {
      // 아바타가 있을 때는 comments 아이콘 제거
      el.querySelectorAll('.replies-footer-icon-comments').forEach(function(c) { c.remove() })
    }

    // 댓글 수 텍스트
    var ftxt = el.querySelector('.replies-footer-text .i18n') || el.querySelector('.i18n')
    if (ftxt) {
      ftxt.textContent = _commentCount > 0
        ? _commentCount + (_commentCount === 1 ? ' Comment' : ' Comments')
        : 'Leave a comment'
    }

    // 댓글 아바타 (최대 3개) — 캐시된 작성자 사용
    if (_commentCount > 0) {
      var avatarCount = authorNames.length

      var wrap = document.createElement('div')
      wrap.className = 'stacked-avatars replies-footer-avatars'
      wrap.style.setProperty('--avatar-size', '30px')

      for (var ai = 0; ai < avatarCount; ai++) {
        var container = document.createElement('div')
        container.className = 'stacked-avatars-avatar-container'
        if (ai === 0) container.classList.add('is-first')
        if (ai === avatarCount - 1) container.classList.add('is-last')

        var avatar = document.createElement('div')
        avatar.className = 'avatar avatar-like avatar-30 avatar-gradient stacked-avatars-avatar'
        if (authorNames[ai] === '__channel__' && _userSettings && _userSettings.channelAvatarUrl) {
          // 채널 아바타 이미지 렌더링
          var img = document.createElement('img')
          img.src = _userSettings.channelAvatarUrl
          img.style.cssText = 'width:100%;height:100%;border-radius:50%;object-fit:cover;'
          avatar.style.background = 'transparent'
          avatar.appendChild(img)
        } else {
          // 이름 해시로 색상 결정
          var nameHash = 0
          for (var ch = 0; ch < authorNames[ai].length; ch++) nameHash += authorNames[ai].charCodeAt(ch)
          avatar.setAttribute('data-color', _tgColors[nameHash % _tgColors.length])
          // 이름의 첫 글자(들) — 한글이면 2자, 영문이면 1자
          var initial = authorNames[ai].slice(0, authorNames[ai].charCodeAt(0) > 255 ? 2 : 1)
          avatar.textContent = initial
        }

        container.appendChild(avatar)
        wrap.appendChild(container)
      }

      el.insertBefore(wrap, el.firstChild)
    }
  }

  // connectedCallback 재렌더링 대응 — 재연결해서 후속 렌더링도 잡음
  var _obsFireCount = 0
  var _repliesObs = new MutationObserver(function() {
    _repliesObs.disconnect()
    _cleanReplies(repliesRe)
    if (_obsFireCount++ < 8) {
      _repliesObs.observe(repliesRe, { childList: true, subtree: true })
    }
  })
  _repliesObs.observe(repliesRe, { childList: true, subtree: true })
  setTimeout(function() { _cleanReplies(repliesRe) }, 300)
  setTimeout(function() { _cleanReplies(repliesRe) }, 800)

  // ── "Leave a comment" 클릭 -> 가짜 댓글 스레드 열기 ──
  var _posRef = pos
  repliesRe.style.cursor = 'pointer'
  repliesRe.addEventListener('click', function(e) {
    e.stopPropagation()
    e.preventDefault()
    toggleCommentThread(bubble, _posRef)
  }, true)
}
