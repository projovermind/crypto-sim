// ── 그룹/위치/날짜그룹 ──────────────────────────────────────────────────────

// ── 그룹 정보 계산 (dom-helpers.js에서 이동) ────────────────────────────────
// 2분(120s) 기준으로 이전/다음 포스트와의 그룹 경계를 판단한다.
function _getGroupInfo(entryTs) {
  const THRESHOLD = 120
  const bubbles = [...document.querySelectorAll('.bubble.channel-post[data-timestamp]')]
    .sort((a, b) => parseInt(a.dataset.timestamp, 10) - parseInt(b.dataset.timestamp, 10))

  let prevTs = null, nextTs = null
  for (const b of bubbles) {
    const ts = parseInt(b.dataset.timestamp, 10)
    if (ts <= entryTs) prevTs = ts
    else if (nextTs === null) { nextTs = ts; break }
  }

  return {
    isGroupFirst: prevTs === null || (entryTs - prevTs) >= THRESHOLD,
    isGroupLast:  nextTs === null || (nextTs - entryTs) >= THRESHOLD,
    prevTs: prevTs, nextTs: nextTs,
  }
}

// ── DOM 삽입 및 그룹 처리 ────────────────────────────────────────────────────
function _insertBubbleIntoDOM(bubble, group, entryTs, pos, posId, isGroupFirst, isGroupLast, forceInsert) {
  var joinedExistingGroup = false

  if (!isGroupFirst) {
    var prevInjected = [...document.querySelectorAll('.bubble.channel-post.teledit-injected[data-timestamp]')]
      .filter(function(b) {
        var ts = parseInt(b.dataset.timestamp, 10)
        return ts < entryTs && (entryTs - ts) < 120
      })
      .sort(function(a, b) { return parseInt(b.dataset.timestamp, 10) - parseInt(a.dataset.timestamp, 10) })[0]

    if (prevInjected) {
      var prevGroup = prevInjected.closest('.bubbles-group.teledit-injected-group')
      if (prevGroup) {
        group = prevGroup
        prevGroup.appendChild(bubble)
        joinedExistingGroup = true
        prevInjected.classList.remove('is-group-last', 'can-have-tail')
        prevInjected.querySelector('.bubble-tail')?.remove()
      }
    }
  }

  if (!joinedExistingGroup) {
    group.appendChild(bubble)

    var allPosts = document.querySelectorAll('.bubble.channel-post[data-timestamp]')
    var sameDayPosts = []
    allPosts.forEach(function(b) { sameDayPosts.push(b) })
    sameDayPosts.sort(function(a, b) {
      return parseInt(a.dataset.timestamp) - parseInt(b.dataset.timestamp)
    })

    var realPosts = document.querySelectorAll('.bubble.channel-post[data-timestamp]:not(.teledit-injected)')
    var inserted = false
    if (realPosts.length) {
      var minRealTs = Infinity
      realPosts.forEach(function(b) {
        var ts = parseInt(b.dataset.timestamp, 10)
        if (ts < minRealTs) minRealTs = ts
      })
      var maxRealTs = -Infinity
      realPosts.forEach(function(b) { var ts = parseInt(b.dataset.timestamp, 10); if (ts > maxRealTs) maxRealTs = ts })
      if (!forceInsert && (entryTs < minRealTs || entryTs > maxRealTs)) {
        if (posId) pendingBubbles.set(posId, { text: bubble.querySelector('.translatable-message')?.textContent || '', pos: pos })
        bubble.remove()
        group.remove()
        return false
      }
    }
    if (sameDayPosts.length) {
      var insertBefore = null
      for (var j = 0; j < sameDayPosts.length; j++) {
        if (parseInt(sameDayPosts[j].dataset.timestamp) > entryTs) {
          insertBefore = sameDayPosts[j]
          break
        }
      }
      if (insertBefore) {
        var pg = insertBefore.closest('.bubbles-group')
        if (pg && pg.parentElement) {
          pg.parentElement.insertBefore(group, pg)
          inserted = true
        }
      }
      if (!inserted) {
        var lastPg = sameDayPosts[sameDayPosts.length - 1].closest('.bubbles-group')
        if (lastPg && lastPg.parentElement) {
          lastPg.parentElement.insertBefore(group, lastPg.nextSibling)
          inserted = true
        }
      }
    }
    if (!inserted) {
      var dg = document.querySelectorAll('.bubbles-date-group')
      if (dg.length) dg[dg.length - 1].appendChild(group)
    }

    // ── sticky 헤더 수정: 다른 날짜의 date-group에 삽입됐으면 별도 date-group 생성
    var parentDateGroup = group.closest('.bubbles-date-group')
    if (parentDateGroup) {
      var dgDateBubble = parentDateGroup.querySelector('.bubble.service.is-date:not(.teledit-date-sep)')
      if (dgDateBubble) {
        var dgText = (dgDateBubble.querySelector('.i18n') || dgDateBubble).textContent.trim()
        var myLabel = _formatDateLabel(entryTs)
        if (dgText !== myLabel) {
          var newDateGroup = document.createElement('div')
          newDateGroup.className = 'bubbles-date-group teledit-date-group'
          var dateSep = _buildDateSeparator(entryTs)
          newDateGroup.appendChild(dateSep)
          newDateGroup.appendChild(group)
          parentDateGroup.parentElement.insertBefore(newDateGroup, parentDateGroup.nextSibling)
        }
      }
    }

    // ── 이전 그룹과의 간격 ──
    var prevGroupEl = group.previousElementSibling
    if (prevGroupEl && prevGroupEl.classList.contains('bubbles-group')) {
      if (!isGroupFirst) {
        var lastPrevBubble = prevGroupEl.querySelector('.bubble:last-child')
        if (lastPrevBubble) {
          lastPrevBubble.classList.remove('is-group-last', 'can-have-tail')
          lastPrevBubble.querySelector('.bubble-tail')?.remove()
        }
      } else if (prevGroupEl.classList.contains('bubbles-group-last')) {
        group.style.marginTop = '6px'
      }
    }

    // ── 다음 그룹과의 간격 ──
    if (!isGroupLast) {
      var nextGroupEl = group.nextElementSibling
      if (nextGroupEl && nextGroupEl.classList.contains('bubbles-group') &&
          !nextGroupEl.classList.contains('teledit-injected-group')) {
        var firstNextBubble = nextGroupEl.querySelector('.bubble:first-child')
        if (firstNextBubble) {
          firstNextBubble.classList.remove('is-group-first')
        }
      }
    }
  }

  return true
}
